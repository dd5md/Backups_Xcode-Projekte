import SwiftUI

// Stil.swift – die Grundlage für die Optik von xSDR64 (Design-Vorgabe 01.10.2026,
// Vorbild RimuSDR). Hier stehen Schrift, Abstände, Ecken und der Knopfstil.
// Farben stehen in Theme.swift.
//
// Regel: Im übrigen Code steht keine Zahl mehr bei .font(.system(size:)) und keine
// eigene Abstandszahl – immer Schrift.… und Abstand.… von hier.
// Noch ist nichts davon im Einsatz: die Blöcke werden einzeln umgestellt.

// MARK: - Schrift: drei Größen, zwei Gewichte
enum Schrift {
  /// Beschriftungen, Überschriften in Großbuchstaben
  static let klein = Font.system(size: 11)
  static let kleinFett = Font.system(size: 11, weight: .semibold)
  /// Werte und normaler Text
  static let normal = Font.system(size: 13)
  static let normalFett = Font.system(size: 13, weight: .semibold)
  /// wichtige Werte, Titel
  static let gross = Font.system(size: 16, weight: .semibold)
  /// Ausnahme: die große Frequenzanzeige
  static let frequenz = Font.system(size: 20, weight: .medium).monospacedDigit()
  /// Zahlen immer mit gleich breiten Ziffern
  static let zahl = Font.system(size: 13).monospacedDigit()
}

// MARK: - Abstände: nur 4 / 8 / 12 / 16
enum Abstand {
  static let xs: CGFloat = 4
  static let s: CGFloat = 8
  static let m: CGFloat = 12
  static let l: CGFloat = 16
}

// MARK: - Maße
enum Mass {
  /// Höhe aller Knöpfe und Auswahlfelder (RimuSDR: 22–24)
  static let knopfHoehe: CGFloat = 23
  /// Höhe einer Zeile in einem Block (RimuSDR: 27–30)
  static let zeilenHoehe: CGFloat = 28
}

// MARK: - Ecken
enum Radius {
  /// Knöpfe, Auswahl- und Zahlenfelder – in RimuSDR nur leicht gerundet
  static let knopf: CGFloat = 3
  /// kleine Kästen
  static let klein: CGFloat = 6
  /// große Kästen
  static let gross: CGFloat = 10
}

// MARK: - Knopfstil (RimuSDR-Farben, Vorlage AppleKnopf aus xHost64)
enum KnopfArt {
  case aus      // grau
  case an       // blau (z. B. MOX, Tabs)
  case gruen    // eingeschaltet
  case rot      // TX, Stopp, Warnung
}

struct KnopfStil: ButtonStyle {
  @Environment(\.isEnabled) private var isEnabled
  var art: KnopfArt = .aus
  /// gleiche Breite für mehrere Knöpfe nebeneinander (nil = so breit wie die Schrift)
  var breite: CGFloat? = nil

  private var verlauf: [Color] {
    guard isEnabled else { return [Theme.knopfGesperrt, Theme.knopfGesperrt] }
    switch art {
    case .aus: return [Theme.knopfAusOben, Theme.knopfAusUnten]
    case .an: return [Theme.knopfAnOben, Theme.knopfAnUnten]
    case .gruen: return [Theme.meterValue.opacity(0.85), Theme.meterValue.opacity(0.65)]
    case .rot: return [Theme.txOn, Theme.txOn.opacity(0.85)]
    }
  }

  /// Lichtkante: oben heller, unten etwas dunkler
  private var kante: [Color] {
    guard isEnabled else { return [.clear, .clear] }
    switch art {
    case .aus: return [Theme.knopfLichtOben, Theme.knopfLichtUnten]
    case .an: return [Theme.knopfAnRand, Theme.knopfAnRand.opacity(0.6)]
    case .gruen, .rot: return [Color.white.opacity(0.30), Color.white.opacity(0.08)]
    }
  }

  func makeBody(configuration: Configuration) -> some View {
    configuration.label
      .font(Schrift.normal)
      .foregroundStyle(isEnabled ? Color.white : Theme.textDim)
      .lineLimit(1)
      .minimumScaleFactor(0.8)  // lange Beschriftung (z. B. „DAXIQ“) lieber etwas kleiner als „DAX…“
      .padding(.horizontal, Abstand.s)
      .frame(minWidth: breite)
      .frame(height: Mass.knopfHoehe)
      .background(
        RoundedRectangle(cornerRadius: Radius.knopf)
          .fill(LinearGradient(colors: verlauf, startPoint: .top, endPoint: .bottom))
          .brightness(configuration.isPressed ? -0.08 : 0)
      )
      // innen: feine Lichtkante
      .overlay(
        RoundedRectangle(cornerRadius: Radius.knopf)
          .inset(by: 1)
          .strokeBorder(LinearGradient(colors: kante, startPoint: .top, endPoint: .bottom), lineWidth: 1)
      )
      // außen: dunkler Rand
      .overlay(
        RoundedRectangle(cornerRadius: Radius.knopf)
          .strokeBorder(Theme.knopfRand, lineWidth: 1)
      )
      .contentShape(Rectangle())
      .animation(.easeOut(duration: 0.1), value: configuration.isPressed)
  }
}

// MARK: - Eingeprägte Trennlinie („Furche“) – 1 px dunkel, 1 px hell (aus xHost64)
struct Furche: View {
  var senkrecht = false

  var body: some View {
    if senkrecht {
      HStack(spacing: 0) {
        Rectangle().fill(Color.black.opacity(0.7)).frame(width: 1)
        Rectangle().fill(Color.white.opacity(0.11)).frame(width: 1)
      }
    } else {
      VStack(spacing: 0) {
        Rectangle().fill(Color.black.opacity(0.7)).frame(height: 1)
        Rectangle().fill(Color.white.opacity(0.11)).frame(height: 1)
      }
    }
  }
}

// MARK: - Eingelassenes Zahlenfeld (Vorlage: Wertfeld neben der LED in xHost64)
extension View {
  /// Kleines eingelassenes Feld für Zahlenwerte: runde Ecken, leichter Innenschatten
  func zahlFeld() -> some View {
    self
      .font(Schrift.zahl)
      .padding(.horizontal, Abstand.xs + 2)
      .frame(height: Mass.knopfHoehe)
      .background(
        RoundedRectangle(cornerRadius: Radius.knopf)
          .fill(Theme.zahlFeld.shadow(.inner(color: .black.opacity(0.5), radius: 1.5, y: 1)))
      )
      .overlay(
        RoundedRectangle(cornerRadius: Radius.knopf)
          .strokeBorder(Theme.knopfRand, lineWidth: 1)
      )
  }
}
