import ApiPackage
import Foundation
import Observation
import Synchronization

// MARK: - Sender (eigene Queue, nicht der Haupt-Thread)

/// Holt das Signal vom Kettenende (NetzAbgriff), rechnet es auf 24 kHz um
/// und schickt es als DAX-TX-Pakete ans Radio: je 128 Samples, Stereo (L = R), Float32 Big Endian.
nonisolated final class DaxTxSender: @unchecked Sendable {
  static let shared = DaxTxSender()

  private let queue = DispatchQueue(label: "xSDR64.DaxTx", qos: .userInteractive)
  private var uhr: DispatchSourceTimer?
  private var streamId: UInt32 = 0
  private var folge: UInt8 = 0          // Paketzähler 0…15
  private var samplezaehler: UInt64 = 0
  private weak var api: ApiModel?

  // Umrechnung Kettentakt → 24 kHz: Tiefpass (FIR) gegen Aliasing, dann Abtasten
  private var takt = 0
  private var filter = [Float]()
  private var verlauf = [Float]()       // letzte Eingangswerte für den Filter
  private var verlaufPos = 0
  private var position: Double = 0      // Bruchteil-Position für das Abtasten
  private var letzter: Float = 0        // letzter gefilterter Wert (für Zwischenwerte)
  private var eingang = [Float](repeating: 0, count: 8192)
  private var ausgang = [Float]()       // fertige 24-kHz-Samples, noch nicht gesendet
  private var paket = [UInt8](repeating: 0, count: 28 + 128 * 8)

  /// Gesendete Pakete (zur Kontrolle)
  private(set) var gesendet = 0

  func starten(streamId: UInt32, api: ApiModel) {
    queue.async { [self] in
      self.streamId = streamId
      self.api = api
      folge = 0
      samplezaehler = 0
      ausgang.removeAll(keepingCapacity: true)
      takt = 0
      NetzAbgriff.ring.leeren()
      let t = DispatchSource.makeTimerSource(flags: .strict, queue: queue)
      t.schedule(deadline: .now(), repeating: .microseconds(2_500), leeway: .microseconds(250))
      t.setEventHandler { [weak self] in self?.tick() }
      uhr = t
      t.resume()
    }
  }

  func stoppen() {
    queue.async { [self] in
      uhr?.cancel()
      uhr = nil
      streamId = 0
    }
  }

  private func tick() {
    let neuerTakt = NetzAbgriff.takt.load(ordering: .relaxed)
    guard neuerTakt > 0, streamId != 0, let api else { return }
    if neuerTakt != takt { filterBauen(neuerTakt) }
    let n = eingang.withUnsafeMutableBufferPointer { NetzAbgriff.ring.lies($0.baseAddress!, maximal: $0.count) }
    guard n > 0 else { return }
    let schritt = Double(takt) / 24_000
    for i in 0..<n {
      // Tiefpass auf den Eingangswert
      verlauf[verlaufPos] = eingang[i]
      var y: Float = 0
      var k = verlaufPos
      for c in filter {
        y += c * verlauf[k]
        k = k == 0 ? verlauf.count - 1 : k - 1
      }
      verlaufPos = (verlaufPos + 1) % verlauf.count
      // auf 24 kHz abtasten (bei 48 kHz: jeder zweite Wert, sonst mit Zwischenwert)
      position += 1
      while position >= schritt {
        position -= schritt
        let t = Float(position)            // so weit liegt der Abtastpunkt vor y
        ausgang.append(y - t * (y - letzter))
      }
      letzter = y
    }
    while ausgang.count >= 128 {
      senden(api)
      ausgang.removeFirst(128)
    }
  }

  /// Gefensterter Sinc-Tiefpass (Blackman), Grenze 10,5 kHz – lässt Sprache unberührt
  private func filterBauen(_ neuerTakt: Int) {
    takt = neuerTakt
    let taps = 63
    let fc = 10_500.0 / Double(neuerTakt)
    var h = [Float](repeating: 0, count: taps)
    let m = Double(taps - 1)
    var summe = 0.0
    for i in 0..<taps {
      let x = Double(i) - m / 2
      let sinc = x == 0 ? 2 * fc : sin(2 * .pi * fc * x) / (.pi * x)
      let w = 0.42 - 0.5 * cos(2 * .pi * Double(i) / m) + 0.08 * cos(4 * .pi * Double(i) / m)
      h[i] = Float(sinc * w)
      summe += sinc * w
    }
    filter = h.map { $0 / Float(summe) }
    verlauf = [Float](repeating: 0, count: taps)
    verlaufPos = 0
    position = 0
    letzter = 0
  }

  /// Ein VITA-Paket bauen (Kopf 7 Wörter wie FlexLib) und direkt per UDP senden
  private func senden(_ api: ApiModel) {
    let woerter: UInt16 = 7 + 256
    paket.withUnsafeMutableBytes { p in
      p[0] = 0x18                        // IF-Daten mit Stream-ID, Class-ID vorhanden
      p[1] = 0xD0 | (folge & 0x0F)       // Zeitstempel: other / Sample-Zähler
      p.storeBytes(of: woerter.bigEndian, toByteOffset: 2, as: UInt16.self)
      p.storeBytes(of: streamId.bigEndian, toByteOffset: 4, as: UInt32.self)
      p.storeBytes(of: UInt32(0x0000_1C2D).bigEndian, toByteOffset: 8, as: UInt32.self)   // Flex OUI
      p.storeBytes(of: UInt32(0x534C_03E3).bigEndian, toByteOffset: 12, as: UInt32.self)  // DAX-Audio Float
      p.storeBytes(of: UInt32(0).bigEndian, toByteOffset: 16, as: UInt32.self)
      p.storeBytes(of: samplezaehler.bigEndian, toByteOffset: 20, as: UInt64.self)
      for i in 0..<128 {
        let bits = ausgang[i].bitPattern.bigEndian
        p.storeBytes(of: bits, toByteOffset: 28 + i * 8, as: UInt32.self)       // links
        p.storeBytes(of: bits, toByteOffset: 28 + i * 8 + 4, as: UInt32.self)   // rechts
      }
    }
    api.sendUdpDirekt(Data(paket))
    folge &+= 1
    samplezaehler &+= 128
    gesendet += 1
  }
}

// MARK: - Schalter für die Oberfläche (Knopf „Audiokette“ im MIC-Block)

/// Sendeweg über die Audiokette per Netz: Kettenende → DAX TX → Radio sendet.
/// Das Radio nimmt dann den Ton von DAX statt vom Mikrofon-Eingang.
@MainActor
@Observable
final class TxNetz {
  static let shared = TxNetz()
  private init() {}

  private(set) var aktiv = false
  private(set) var meldung = ""
  private var radio: RadioVerbindung { RadioVerbindung.shared }

  func umschalten() { aktiv ? stoppen() : starten() }

  func starten() {
    guard !aktiv, radio.istVerbunden else { return }
    aktiv = true
    meldung = "verbinde …"
    let vorher = Set(radio.api.daxTxAudios.map(\.id))
    radio.sende("stream create type=dax_tx")
    Task {
      // warten, bis das Radio den neuen Sende-Stream meldet
      for _ in 0..<40 {
        if let neu = radio.api.daxTxAudios.first(where: { !vorher.contains($0.id) && $0.clientHandle == radio.api.connectionHandle })
            ?? radio.api.daxTxAudios.first(where: { $0.clientHandle == radio.api.connectionHandle }) {
          guard aktiv else { return }
          DaxTxSender.shared.starten(streamId: neu.id, api: radio.api)
          AudioWelt.shared.host.netzAusgangAktiv = true     // Kettenende abgreifen
          radio.sende("transmit set dax=1")                 // Radio sendet den DAX-Ton
          meldung = "DAX TX 0x\(String(neu.id, radix: 16, uppercase: true))"
          return
        }
        try? await Task.sleep(for: .milliseconds(100))
      }
      meldung = "Radio hat keinen Sende-Stream gemeldet"
      stoppen()
    }
  }

  func stoppen() {
    guard aktiv else { return }
    aktiv = false
    if radio.istVerbunden {
      radio.sende("transmit set dax=0")                     // zurück auf den Mikrofon-Eingang
      for s in radio.api.daxTxAudios where s.clientHandle == radio.api.connectionHandle {
        radio.sende("stream remove 0x\(String(s.id, radix: 16, uppercase: true))")
      }
    }
    DaxTxSender.shared.stoppen()
    AudioWelt.shared.host.netzAusgangAktiv = false
    if meldung.hasPrefix("DAX") || meldung.hasPrefix("verbinde") { meldung = "" }
  }
}
