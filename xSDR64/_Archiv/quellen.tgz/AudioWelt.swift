import Foundation

/// Die eine Audiokette der App – gemeinsam für das Hauptfenster und das Plugin-Fenster.
/// (Vorher lag sie im Hauptfenster; ein eigenes Fenster braucht aber Zugriff darauf.)
final class AudioWelt {
  static let shared = AudioWelt()
  let host = AudioHost()
  let catalog = PluginCatalog()
  private init() {}
}
