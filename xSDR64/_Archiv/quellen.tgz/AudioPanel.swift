import AppKit
import SwiftUI

/// Linkes Panel: die Audiokette aus xHost64 – hochkant.
/// Kopfzeile: Zahnrad (Geräte/Kanäle), „+“ (neue Kette), Start/Stop.
/// Darunter entweder die Ketten oder die Audio-Einstellungen.
/// „+ Plugin“ in einer Kette fährt rechts daneben die Plugin-Liste aus.
struct AudioPanel: View {
    let host: AudioHost
    let catalog: PluginCatalog
    @State private var settingsOpen = false   // Zahnrad: Einstellungen statt Ketten
    @State private var pluginsOpen = false    // Plugin-Liste (Popup)
    @State private var statsOpen = false      // Pegel-Info (Popup)

    /// Breite der Ketten-Spalte (schmaler als in xHost64)
    static let chainWidth: CGFloat = 430

    var body: some View {
        HStack(spacing: 0) {
            VStack(spacing: 0) {
                header
                if settingsOpen {
                    ScrollView { SettingsPanel(host: host) }
                } else {
                    CompactChainsList(host: host, catalog: catalog, pluginsOpen: $pluginsOpen)
                }
            }
            .frame(width: Self.chainWidth)
        }
        .frame(maxHeight: .infinity)
        .background(Theme.rimuLeiste)
        .overlay(Rectangle().stroke(Theme.border))
    }

    /// Kopfzeile: Titel, Zahnrad, neue Kette, Start/Stop
    private var header: some View {
        HStack(spacing: 8) {
            Text("AUDIOKETTE")
                .font(Schrift.normalFett)
            Spacer(minLength: 0)
            // Zahnrad: Gerät, Samplerate, Kanäle
            Button { settingsOpen.toggle() } label: {
                Image(systemName: "gearshape.fill")
                    .font(Schrift.normal)
                    .foregroundStyle(settingsOpen ? Theme.accent : Theme.text)
                    .frame(width: 26, height: 26)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .focusEffectDisabled()
            .help("Audio-Einstellungen: Gerät, Kanäle, Puffer")
            // ⓘ: Pegel der letzten 3 Sekunden als Popup (statt dauerhaft im Panel)
            Button { statsOpen.toggle() } label: {
                Image(systemName: "info.circle")
                    .font(Schrift.normal)
                    .foregroundStyle(statsOpen ? Theme.accent : Theme.text)
                    .frame(width: 26, height: 26)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .focusEffectDisabled()
            .help("Pegel (3 s): IN/OUT, Gain, Crest, Ziel")
            .popover(isPresented: $statsOpen, arrowEdge: .bottom) {
                CompactStatsBox(host: host)
                    .frame(width: 300)
                    .padding(10)
            }
            // neue, leere Kette
            Button("+ Kette") { host.addChain() }
                .buttonStyle(KnopfStil())
                .help("Neue, leere Audiokette anlegen")
            // Start/Stop – rot, solange die Kette läuft
            Button(host.isRunning ? "Stop" : "Start") {
                if host.isRunning { host.stop() } else { host.start() }
            }
            .buttonStyle(KnopfStil(art: host.isRunning ? .rot : .aus, breite: 60))
        }
        .padding(.horizontal, Abstand.s)
        .frame(height: 36)
        .background(Theme.rimuKopf)
    }
}
