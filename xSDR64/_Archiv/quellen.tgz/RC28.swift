import ApiPackage
import IOKit.hid
import Observation
import SwiftUI

/// ICOM RC-28 (USB-Drehknopf) über IOHIDManager – Apple-Bordmittel, kein Zusatzprogramm.
/// Belegung (wie beim Nutzer in SmartSDR): Rad → Frequenz Slice A, PTT → MOX, F-1 → Zoom raus, F-2 → Zoom rein.
/// Bericht-Aufbau nach wfview: Byte 1 = Anzahl Rasten, Byte 3 = Richtung (1/2),
/// Byte 5 = Tasten (low-aktiv, XOR 0x07: Bit 0 PTT, Bit 1 F-1, Bit 2 F-2) – wird im Fenster live geprüft.
@MainActor
@Observable
final class RC28 {
  static let shared = RC28()

  private let speicher = UserDefaults.standard
  var aktiv: Bool { didSet { speicher.set(aktiv, forKey: "rc28Aktiv"); if !aktiv { pttLoslassen() } } }
  /// PTT schaltet MOX – erst einschalten, wenn im Fenster geprüft ist, dass „PTT“ richtig erkannt wird
  var pttAktiv: Bool { didSet { speicher.set(pttAktiv, forKey: "rc28Ptt"); if !pttAktiv { pttLoslassen() } } }
  var umkehren: Bool { didSet { speicher.set(umkehren, forKey: "rc28Umkehren") } }
  /// true: einmal drücken = senden, nochmal drücken = aus (wie „PTT Push-once“ bei SmartSDR);
  /// false: senden, solange die Taste gedrückt ist
  var pttUmschalten: Bool { didSet { speicher.set(pttUmschalten, forKey: "rc28PttUmschalten"); pttLoslassen() } }
  /// Rasten pro Abstimmschritt-Vielfaches (1 = ein Schritt je Raste)
  var faktor: Int { didSet { speicher.set(faktor, forKey: "rc28Faktor") } }

  private(set) var verbunden = false
  private(set) var rohdaten = "–"
  private(set) var gedrueckt: Set<String> = []
  private(set) var drehungen = 0   // Zähler fürs Fenster

  private var manager: IOHIDManager?
  private var geraet: IOHIDDevice?
  private let puffer = UnsafeMutablePointer<UInt8>.allocate(capacity: 64)
  private var alteTasten: UInt8 = 0
  /// Erster Bericht nach dem Anstecken: nur Zustand merken, keine Aktion (sonst könnte eine
  /// klemmende/als gedrückt gemeldete PTT sofort senden)
  private var ersterBericht = true
  private var sendetPtt = false
  private var rest = 0

  private init() {
    aktiv = speicher.object(forKey: "rc28Aktiv") as? Bool ?? true
    pttAktiv = speicher.bool(forKey: "rc28Ptt")
    umkehren = speicher.bool(forKey: "rc28Umkehren")
    pttUmschalten = speicher.object(forKey: "rc28PttUmschalten") as? Bool ?? true
    faktor = max(1, speicher.integer(forKey: "rc28Faktor"))
    puffer.initialize(repeating: 0, count: 64)
  }

  /// Beim Programmstart einmal aufrufen – meldet sich, sobald ein RC-28 angesteckt wird
  func starten() {
    guard manager == nil else { return }
    let m = IOHIDManagerCreate(kCFAllocatorDefault, IOOptionBits(kIOHIDOptionsTypeNone))
    IOHIDManagerSetDeviceMatching(m, [kIOHIDVendorIDKey: 0x0C26, kIOHIDProductIDKey: 0x001E] as CFDictionary)
    IOHIDManagerRegisterDeviceMatchingCallback(m, { _, _, _, device in
      MainActor.assumeIsolated { RC28.shared.angesteckt(device) }
    }, nil)
    IOHIDManagerRegisterDeviceRemovalCallback(m, { _, _, _, device in
      MainActor.assumeIsolated { RC28.shared.abgezogen(device) }
    }, nil)
    IOHIDManagerScheduleWithRunLoop(m, CFRunLoopGetMain(), CFRunLoopMode.defaultMode.rawValue)
    let ergebnis = IOHIDManagerOpen(m, IOOptionBits(kIOHIDOptionsTypeNone))
    if ergebnis != kIOReturnSuccess { Diagnose.log("RC-28: IOHIDManagerOpen fehlgeschlagen (\(ergebnis))") }
    manager = m
  }

  private func angesteckt(_ device: IOHIDDevice) {
    geraet = device
    verbunden = true
    alteTasten = 0
    ersterBericht = true
    IOHIDDeviceRegisterInputReportCallback(device, puffer, 64, { _, _, _, _, _, bericht, laenge in
      let bytes = Array(UnsafeBufferPointer(start: bericht, count: Int(laenge)))
      MainActor.assumeIsolated { RC28.shared.bericht(bytes) }
    }, nil)
    Diagnose.log("RC-28 angesteckt")
  }

  private func abgezogen(_ device: IOHIDDevice) {
    guard device == geraet else { return }
    pttLoslassen()
    geraet = nil
    verbunden = false
    gedrueckt = []
    Diagnose.log("RC-28 abgezogen")
  }

  /// Ein Bericht vom RC-28 (bei jeder Drehung oder Taste)
  private func bericht(_ b: [UInt8]) {
    rohdaten = b.prefix(8).map { String(format: "%02X", $0) }.joined(separator: " ")
    guard b.count >= 6, b[0] == 0x01 else { return }   // 0x02 = Firmware-Antwort

    // Tasten: low-aktiv → XOR 0x07, dann Bit gesetzt = gedrückt
    let tasten = b[5] ^ 0x07
    if ersterBericht { alteTasten = tasten; ersterBericht = false }
    let neu = tasten & ~alteTasten, los = alteTasten & ~tasten
    alteTasten = tasten
    var anzeige: Set<String> = []
    if tasten & 0x01 != 0 { anzeige.insert("PTT") }
    if tasten & 0x02 != 0 { anzeige.insert("F-1") }
    if tasten & 0x04 != 0 { anzeige.insert("F-2") }
    gedrueckt = anzeige

    if aktiv {
      if pttUmschalten {
        if neu & 0x01 != 0 { pttUmschalt() }
      } else {
        if neu & 0x01 != 0 { pttDruecken() }
        if los & 0x01 != 0 { pttLoslassen() }
      }
      if neu & 0x02 != 0 { zoom(faktor: 2) }     // F-1: Zoom raus (breiter)
      if neu & 0x04 != 0 { zoom(faktor: 0.5) }   // F-2: Zoom rein (enger)
    }

    // Rad
    let rasten = Int(b[1])
    guard rasten > 0, b[3] == 0x01 || b[3] == 0x02 else { return }
    var richtung = b[3] == 0x01 ? 1 : -1
    if umkehren { richtung = -richtung }
    drehungen += richtung * rasten
    if aktiv { drehen(richtung * rasten) }
  }

  private func drehen(_ rasten: Int) {
    let radio = RadioVerbindung.shared
    guard radio.istVerbunden, let slice = radio.meinSlice else { return }
    let schritt = radio.schritt(slice) * faktor
    let basis = slice.frequency / schritt * schritt   // auf glatte Werte einrasten
    radio.stimme(slice, basis + rasten * schritt, autopan: true)
  }

  private func zoom(faktor f: Double) {
    let radio = RadioVerbindung.shared
    guard let slice = radio.meinSlice,
          let pan = radio.api.panadapters.first(where: { $0.id == slice.panadapterId }), pan.bandwidth > 0 else { return }
    radio.panBreite(pan, Double(pan.bandwidth) * f, sofort: true)
  }

  private func pttDruecken() {
    guard pttAktiv, RadioVerbindung.shared.istVerbunden, !sendetPtt else { return }
    sendetPtt = true
    RadioVerbindung.shared.sende("xmit 1")
  }

  /// Umschalt-Modus: richtet sich nach dem echten Sendezustand des Radios –
  /// wurde MOX woanders (Knopf, Timeout) beendet, schaltet der nächste Druck wieder ein
  private func pttUmschalt() {
    let radio = RadioVerbindung.shared
    guard pttAktiv, radio.istVerbunden else { return }
    if sendetPtt || radioSendet {
      sendetPtt = true
      pttLoslassen()
    } else {
      pttDruecken()
    }
  }

  /// Sendet das Radio gerade? „mox“ allein wird nicht zuverlässig gemeldet –
  /// darum auch den Interlock-Zustand prüfen
  var radioSendet: Bool {
    let api = RadioVerbindung.shared.api
    return api.transmit.mox || ["TRANSMITTING", "PTT_REQUESTED"].contains(api.interlock.state.uppercased())
  }

  /// Sicherheit: PTT immer wieder freigeben (Loslassen, Abziehen, Ausschalten)
  private func pttLoslassen() {
    guard sendetPtt else { return }
    sendetPtt = false
    RadioVerbindung.shared.sende("xmit 0")
  }
}

/// Fenster „RC-28“ (Menü Radio): Einstellungen und Live-Anzeige zum Prüfen
struct RC28Fenster: View {
  @State private var rc = RC28.shared

  var body: some View {
    Form {
      Section {
        LabeledContent("Gerät") {
          HStack(spacing: 6) {
            Circle().fill(rc.verbunden ? Theme.meterValue : Theme.ledOff).frame(width: 9, height: 9)
            Text(rc.verbunden ? "Icom RC-28 – verbunden" : "nicht angesteckt")
          }
        }
        Toggle("RC-28 benutzen", isOn: $rc.aktiv).toggleStyle(.checkbox)
      }
      Section("Belegung") {
        LabeledContent("Rad") { Text("Frequenz Slice A") }
        Toggle("Rad-Richtung umkehren", isOn: $rc.umkehren).toggleStyle(.checkbox)
        LabeledContent("Schritt je Raste") {
          Picker("", selection: $rc.faktor) {
            Text("1 × Abstimmschritt").tag(1)
            Text("2 ×").tag(2)
            Text("5 ×").tag(5)
            Text("10 ×").tag(10)
          }
          .labelsHidden().frame(width: 170)
        }
        LabeledContent("F-1 / F-2") { Text("Zoom raus / Zoom rein") }
        Toggle("PTT-Taste schaltet MOX (senden!)", isOn: $rc.pttAktiv).toggleStyle(.checkbox)
        LabeledContent("PTT-Modus") {
          Picker("", selection: $rc.pttUmschalten) {
            Text("Umschalten (drücken = an, nochmal = aus)").tag(true)
            Text("Halten (senden solange gedrückt)").tag(false)
          }
          .labelsHidden().frame(width: 270)
        }
        LabeledContent("Sender") {
          Text(rc.radioSendet ? "SENDET" : "aus")
            .foregroundStyle(rc.radioSendet ? Theme.txOn : Theme.textDim)
        }
        Text("Haken einmal setzen – er bleibt gespeichert. Ohne Haken zeigt „Gedrückt“ die Taste nur an, gesendet wird nicht.")
          .font(Schrift.klein).foregroundStyle(Theme.textDim)
          .fixedSize(horizontal: false, vertical: true)
      }
      Section("Prüfen") {
        LabeledContent("Gedrückt") {
          Text(rc.gedrueckt.isEmpty ? "–" : rc.gedrueckt.sorted().joined(separator: " + "))
            .foregroundStyle(rc.gedrueckt.isEmpty ? Theme.textDim : Theme.meterYellow)
        }
        LabeledContent("Rad-Zähler") { Text("\(rc.drehungen)").font(Schrift.zahl) }
        LabeledContent("Rohdaten") { Text(rc.rohdaten).font(.system(size: 11, design: .monospaced)).textSelection(.enabled) }
      }
    }
    .formStyle(.grouped)
    .frame(width: 480, height: 640)
    .background(Theme.window)
  }
}
