//
//  TXBlock.swift
//  xSDR64
//
//  Created by Mathias Davidheimann on 24.09.26.
//  01.10.2026: auf RimuSDR-Stil umgestellt (Design-Vorgabe)
//

import ApiPackage
import SwiftUI

/// Inhalt des TX-Blocks: Leistungs- und SWR-Anzeige, Regler, TUNE / MOX / ATU
struct TXBlock: View {
  // Ersatzwerte, solange kein Radio verbunden ist – verbunden kommen alle Werte vom Radio
  @State private var rfPower = 100.0
  @State private var tunePower = 25.0
  @State private var tuneOn = false
  @State private var moxOn = false
  @State private var atuOn = false
  @State private var txProfil = "Default"

  private let radio = RadioVerbindung.shared

  var body: some View {
    let tune = radio.txSchalter($tuneOn, \.tune) { "transmit tune \($0 ? 1 : 0)" }
    let mox = radio.txSchalter($moxOn, \.mox) { "xmit \($0 ? 1 : 0)" }
    // „mox“ meldet das Radio nicht zuverlässig – Sendezustand wie beim RC-28 auch über den Interlock
    // (TUNE sendet ebenfalls, dann soll aber nur TUNE rot sein)
    let sendet = radio.istVerbunden
      ? (mox.wrappedValue || RC28.shared.radioSendet) && !tune.wrappedValue
      : mox.wrappedValue
    // ATU leuchtet, solange er abstimmt oder erfolgreich abgestimmt hat
    let atuStatus = radio.istVerbunden ? radio.api.atu.status : .none
    let atuAn = radio.istVerbunden
      ? [.tuneInProgress, .tuneSuccessful, .tuneOK].contains(atuStatus)
      : atuOn
    VStack(spacing: 0) {
      // Messanzeigen auf dunklem Grund – über die ganze Blockbreite
      VStack(spacing: Abstand.s) {
        // Leistung 0…120 W, rot ab 100 W
        RimuMeter(marks: [
          .init(pos: 0, text: "0"),
          .init(pos: 0.333, text: "40"),
          .init(pos: 0.5, text: "RF Pwr"),
          .init(pos: 0.667, text: "80"),
          .init(pos: 0.833, text: "100", red: true),
          .init(pos: 1, text: "120", red: true),
        ], redFrom: 0.833, value: Double((MessModell.shared.leistungWatt ?? 0) / 120), ticks: 12)

        // SWR 1…3, rot ab 2.5
        RimuMeter(marks: [
          .init(pos: 0, text: "1"),
          .init(pos: 0.25, text: "1.5"),
          .init(pos: 0.5, text: "SWR"),
          .init(pos: 0.75, text: "2.5", red: true),
          .init(pos: 1, text: "3", red: true),
        ], redFrom: 0.75, value: Double(((MessModell.shared.swr ?? 1) - 1) / 2), ticks: 8)
      }
      .padding(Abstand.s)
      .background(Theme.rimuMeter)

      // Bedienteil auf der Blockfläche
      VStack(spacing: 0) {
        // TX-Profil (Liste und Auswahl vom Radio)
        HStack(spacing: Abstand.s) {
          Text("TX Profil:")
            .font(Schrift.normal)
            .frame(width: 78, alignment: .leading)
          RimuPicker(selection: radio.profilWahl("tx", $txProfil), options: radio.profilListe("tx")) { $0 }
        }
        .frame(height: Mass.zeilenHoehe)

        ReglerZeile(label: "RF Power:", value: radio.txRegler($rfPower, \.rfPower, "transmit set rfpower"))
        ReglerZeile(label: "Tune Pwr:", value: radio.txRegler($tunePower, \.tunePower, "transmit set tunepower"))

        HStack(spacing: Abstand.xs) {
          // TUNE und MOX senden wirklich – darum rot, solange aktiv
          Button("TUNE") { tune.wrappedValue.toggle() }
            .buttonStyle(KnopfStil(art: tune.wrappedValue ? .rot : .aus, breite: 60))
          Button("MOX") {
            if radio.istVerbunden { radio.sende(sendet ? "xmit 0" : "xmit 1") } else { mox.wrappedValue.toggle() }
          }
            .buttonStyle(KnopfStil(art: sendet ? .rot : .aus, breite: 60))
          Spacer(minLength: 0)
          Button("ATU") {
            if radio.istVerbunden { radio.sende("atu start") } else { atuOn.toggle() }
          }
          .buttonStyle(KnopfStil(art: atuAn ? .an : .aus, breite: 60))
          .help(radio.istVerbunden ? "ATU abstimmen – Status: \(atuStatus.rawValue)" : "ATU")
        }
        .frame(height: Mass.zeilenHoehe)
        .padding(.top, Abstand.xs)
      }
      .padding(.horizontal, Abstand.s)
      .padding(.vertical, Abstand.s)
    }
    .foregroundStyle(Theme.text)
  }
}
