import ApiPackage
import AVFoundation
import Observation
import Synchronization

// MARK: - Ringpuffer (ein Schreiber: UDP-Queue, ein Leser: Audio-Thread – ohne Sperren)

/// Stereo-Ringpuffer für Float-Samples, verschachtelt (L R L R …).
/// Lock-frei: Schreib- und Leseposition sind Atomics, der Audio-Thread wartet nie.
nonisolated final class AudioRing: @unchecked Sendable {
  let kapazitaet: Int  // Stereo-Frames
  private let daten: UnsafeMutablePointer<Float>
  private let schreib = Atomic<Int>(0)  // gesamt geschriebene Frames
  private let lese = Atomic<Int>(0)     // gesamt gelesene Frames

  init(frames: Int) {
    kapazitaet = frames
    daten = .allocate(capacity: frames * 2)
    daten.initialize(repeating: 0, count: frames * 2)
  }
  deinit { daten.deallocate() }

  var fuellstand: Int { schreib.load(ordering: .acquiring) - lese.load(ordering: .acquiring) }

  /// Schreibt Frames (verschachtelt). Ist der Puffer zu voll, gewinnen die neuen Daten.
  func schreibe(_ quelle: UnsafePointer<Float>, frames: Int) {
    let s = schreib.load(ordering: .relaxed)
    for i in 0..<frames {
      let p = ((s + i) % kapazitaet) * 2
      daten[p] = quelle[2 * i]
      daten[p + 1] = quelle[2 * i + 1]
    }
    schreib.store(s + frames, ordering: .releasing)
  }

  /// Liest Frames in zwei getrennte Kanäle; was fehlt, wird mit Stille gefüllt. Gibt gelesene Frames zurück.
  func lies(links: UnsafeMutablePointer<Float>, rechts: UnsafeMutablePointer<Float>, frames: Int) -> Int {
    let l = lese.load(ordering: .relaxed)
    let vorhanden = min(frames, schreib.load(ordering: .acquiring) - l)
    for i in 0..<max(0, vorhanden) {
      let p = ((l + i) % kapazitaet) * 2
      links[i] = daten[p]
      rechts[i] = daten[p + 1]
    }
    for i in max(0, vorhanden)..<frames {
      links[i] = 0
      rechts[i] = 0
    }
    lese.store(l + max(0, vorhanden), ordering: .releasing)
    return max(0, vorhanden)
  }

  /// Überzählige Frames verwerfen, damit die Verzögerung nicht wächst (nur vom Leser aufrufen)
  func kuerzeAuf(_ frames: Int) {
    let s = schreib.load(ordering: .acquiring)
    let l = lese.load(ordering: .relaxed)
    if s - l > frames { lese.store(s - frames, ordering: .releasing) }
  }

  func leeren() { lese.store(schreib.load(ordering: .acquiring), ordering: .releasing) }
}

// MARK: - Empfang (UDP-Queue)

/// Nimmt den Empfangston des Radios an (remote_audio_rx unkomprimiert:
/// 24 kHz, Stereo, Float32 Big Endian, verschachtelt) und schreibt ihn in den Ringpuffer.
nonisolated final class MacAudioEmpfang: @unchecked Sendable {
  static let shared = MacAudioEmpfang()

  let ring = AudioRing(frames: 24_000)  // 1 s Platz
  /// nur Pakete dieses Streams annehmen (0 = keiner)
  let streamId = Atomic<UInt32>(0)

  private var puffer = [Float](repeating: 0, count: 4096)

  var rueckruf: @Sendable (UInt32, [UInt8]) -> Void {
    { [self] id, payload in self.paket(id, payload) }
  }

  func paket(_ id: UInt32, _ p: [UInt8]) {
    guard id != 0, id == streamId.load(ordering: .relaxed) else { return }
    let werte = p.count / 4
    let frames = werte / 2
    guard frames > 0 else { return }
    if puffer.count < werte { puffer = [Float](repeating: 0, count: werte) }
    p.withUnsafeBytes { roh in
      for i in 0..<werte {
        let bits = UInt32(bigEndian: roh.loadUnaligned(fromByteOffset: i * 4, as: UInt32.self))
        puffer[i] = Float(bitPattern: bits)
      }
    }
    puffer.withUnsafeBufferPointer { ring.schreibe($0.baseAddress!, frames: frames) }
  }
}

// MARK: - Wiedergabe am Mac

/// Empfangston über das Netz am Mac abspielen (Knopf „Audio: Mac“).
/// Verzögerung klein halten: Start bei ~40 ms Vorrat, mehr als ~120 ms wird verworfen.
@MainActor
@Observable
final class MacAudio {
  static let shared = MacAudio()

  /// gewünschter Weg – bleibt über Neustarts erhalten
  var aufMac: Bool = UserDefaults.standard.bool(forKey: "audioAufMac") {
    didSet {
      UserDefaults.standard.set(aufMac, forKey: "audioAufMac")
      anwenden()
    }
  }
  /// Lautstärke am Mac 0…1
  var lautstaerke: Float = 0.6 { didSet { engine.mainMixerNode.outputVolume = stumm ? 0 : lautstaerke } }
  var stumm = false { didSet { engine.mainMixerNode.outputVolume = stumm ? 0 : lautstaerke } }

  /// Ausgabegerät (feste UID, leer = Standard des Systems) – bleibt über Neustarts erhalten
  var ausgabeUID: String = UserDefaults.standard.string(forKey: "audioAusgabeUID") ?? "" {
    didSet {
      UserDefaults.standard.set(ausgabeUID, forKey: "audioAusgabeUID")
      neuStarten()
    }
  }

  /// Puffer: 0 = klein (20/60 ms), 1 = mittel (40/120 ms), 2 = groß (80/240 ms)
  var puffer: Int = UserDefaults.standard.object(forKey: "audioPuffer") as? Int ?? 1 {
    didSet {
      UserDefaults.standard.set(puffer, forKey: "audioPuffer")
      neuStarten()
    }
  }

  /// Alle Mac-Geräte mit Ausgang (frisch gelesen – neu angesteckte erscheinen sofort)
  var ausgaben: [AudioDevice] { AudioDevices.all().filter { $0.outputChannels > 0 } }

  private(set) var laeuft = false
  private let engine = AVAudioEngine()
  private var quelle: AVAudioSourceNode?
  private var radio: RadioVerbindung { RadioVerbindung.shared }

  private init() {}

  /// Nach Verbinden, Trennen oder Umschalten aufrufen
  func anwenden() {
    if aufMac && radio.istVerbunden { starten() } else { stoppen() }
  }

  /// Gerät oder Puffer geändert: Wiedergabe kurz neu aufbauen (der Netzstrom bleibt bestehen)
  private func neuStarten() {
    guard laeuft else { return }
    engine.stop()
    if let quelle { engine.detach(quelle) }
    quelle = nil
    laeuft = false
    wiedergabeStarten()
  }

  private func starten() {
    guard !laeuft else { return }
    guard wiedergabeStarten() else { return }
    // Radio: Empfangston über das Netz schicken (unkomprimiert, im LAN die kleinste Verzögerung)
    radio.api.sendTcp("stream create type=remote_audio_rx compression=none")
    beobachteStream()
  }

  /// Engine mit Quelle aufbauen und auf dem gewählten Gerät starten
  @discardableResult
  private func wiedergabeStarten() -> Bool {
    MacAudioEmpfang.shared.ring.leeren()
    if !ausgabeUID.isEmpty, let geraet = ausgaben.first(where: { $0.uid == ausgabeUID }) {
      try? engine.outputNode.auAudioUnit.setDeviceID(geraet.id)
    }
    let format = AVAudioFormat(standardFormatWithSampleRate: 24_000, channels: 2)!
    let grenzen = [(480, 1440), (960, 2880), (1920, 5760)][min(max(puffer, 0), 2)]
    let node = AVAudioSourceNode(format: format,
                                 renderBlock: Self.renderBlock(MacAudioEmpfang.shared.ring, start: grenzen.0, maximal: grenzen.1))
    engine.attach(node)
    engine.connect(node, to: engine.mainMixerNode, format: format)
    engine.mainMixerNode.outputVolume = stumm ? 0 : lautstaerke
    do {
      try engine.start()
    } catch {
      engine.detach(node)
      return false
    }
    quelle = node
    laeuft = true
    return true
  }

  private func stoppen() {
    guard laeuft else { return }
    if let id = radio.api.remoteRxAudio?.id, radio.istVerbunden {
      radio.sende("stream remove 0x\(String(id, radix: 16, uppercase: true))")
    }
    MacAudioEmpfang.shared.streamId.store(0, ordering: .relaxed)
    engine.stop()
    if let quelle { engine.detach(quelle) }
    quelle = nil
    laeuft = false
  }

  /// Wartet, bis das Radio den Stream gemeldet hat, und lässt dann seine Pakete durch
  private func beobachteStream() {
    Task {
      for _ in 0..<40 {
        if let id = radio.api.remoteRxAudio?.id {
          MacAudioEmpfang.shared.streamId.store(id, ordering: .relaxed)
          return
        }
        try? await Task.sleep(for: .milliseconds(100))
      }
    }
  }

  /// Render-Block für den Audio-Thread – hier gebaut, damit er nicht an den Haupt-Thread gebunden ist
  /// start: so viel Vorrat (Frames bei 24 kHz), bevor es losgeht; maximal: mehr wird verworfen
  nonisolated static func renderBlock(_ ring: AudioRing, start: Int, maximal: Int) -> AVAudioSourceNodeRenderBlock {
    let vorratAufgebaut = Schalter()  // Atomic selbst lässt sich nicht in den Block mitnehmen
    return { _, _, frameCount, abl -> OSStatus in
      let liste = UnsafeMutableAudioBufferListPointer(abl)
      guard liste.count >= 2,
            let l = liste[0].mData?.assumingMemoryBound(to: Float.self),
            let r = liste[1].mData?.assumingMemoryBound(to: Float.self) else { return noErr }
      let n = Int(frameCount)
      if !vorratAufgebaut.wert.load(ordering: .relaxed) {
        if ring.fuellstand >= start {
          vorratAufgebaut.wert.store(true, ordering: .relaxed)
        } else {
          for i in 0..<n { l[i] = 0; r[i] = 0 }
          return noErr
        }
      }
      ring.kuerzeAuf(maximal)
      let gelesen = ring.lies(links: l, rechts: r, frames: n)
      if gelesen < n { vorratAufgebaut.wert.store(false, ordering: .relaxed) }  // leergelaufen: neu ansammeln
      return noErr
    }
  }
}

/// Kleine Hülle um ein Atomic, damit der Render-Block es mitnehmen kann
nonisolated final class Schalter: Sendable {
  let wert = Atomic<Bool>(false)
}
