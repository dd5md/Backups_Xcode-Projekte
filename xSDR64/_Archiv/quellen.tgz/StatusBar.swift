import ApiPackage
import SwiftUI

/// Untere Leiste: links Schalter (TNF, DVK, FDX), Mitte Radio/Station/RC-28,
/// rechts Sendebereitschaft, Spannung, Temperatur und UTC-Uhr
struct StatusBar: View {
  // Ersatzwerte ohne Radio (TNF/FDX kommen verbunden vom Radio; DVK folgt mit dem Aufnahmen-Fenster)
  @State private var tnfOn = false
  @State private var dvkOn = false
  @State private var fdxOn = false
  @State private var zeigeRadios = false
  private let verbindung = RadioVerbindung.shared
  private var connected: Bool { verbindung.istVerbunden }
  private var rc28: Bool { RC28.shared.verbunden }  // RC-28 angeschlossen?
  // NOCH FEST (nicht angeschlossen): Netzqualität-Balken und Lampe „TX Ready“
  private let signal = 3  // Netzqualität 0…4 Balken
  private let txReady = true
  private let volts = 13.8    // Ersatz, solange kein Messwert vom Radio kommt
  private let celsius = 27

  /// Uhrzeit in UTC (hh:mm:ss)
  private static let utcFormat: DateFormatter = {
    let f = DateFormatter()
    f.dateFormat = "HH:mm:ss"
    f.timeZone = TimeZone(identifier: "UTC")
    return f
  }()

  var body: some View {
    HStack(spacing: 14) {
      // Puls: zeigt, dass Daten vom Radio kommen
      Image(systemName: "waveform.path.ecg")
        .foregroundStyle(connected ? Theme.meterValue : Theme.textDim)
        .help(connected ? "Verbunden – Daten kommen an" : "Nicht verbunden")

      HStack(spacing: 4) {
        // TNF (global) und FDX (Full Duplex) zeigen und schalten den Zustand des Radios
        let r = verbindung.radio
        TagButton(title: "TNF", isOn: r?.tnfsEnabled ?? tnfOn) {
          if let r { verbindung.sende("radio set tnf_enabled=\(r.tnfsEnabled ? 0 : 1)") } else { tnfOn.toggle() }
        }
        TagButton(title: "DVK", isOn: dvkOn) { dvkOn.toggle() }   // Sprachspeicher – kommt mit dem Aufnahmen-Fenster
        TagButton(title: "FDX", isOn: r?.fullDuplexEnabled ?? fdxOn) {
          if let r { verbindung.sende("radio set full_duplex_enabled=\(r.fullDuplexEnabled ? 0 : 1)") } else { fdxOn.toggle() }
        }
      }

      Spacer(minLength: 0)

      // Radio (Klick: Radio wählen / trennen), Station, RC-28, Netzqualität
      Button { zeigeRadios.toggle() } label: {
        HStack(spacing: 5) {
          Circle()
            .fill(connected ? Theme.meterValue : Theme.control)
            .overlay(Circle().stroke(Theme.controlBorder))
            .frame(width: 9, height: 9)
          Text(radioText)
            .foregroundStyle(connected ? Theme.text : Theme.textDim)
        }
      }
      .buttonStyle(.plain)
      .help("Radio wählen, verbinden oder trennen")
      .popover(isPresented: $zeigeRadios, arrowEdge: .top) {
        RadioAuswahl()
      }
      if connected {
        Text("Station: \(RadioVerbindung.stationName)")
          .foregroundStyle(Theme.textDim)
      }
      lamp("RC-28", on: rc28)
      Image(systemName: "cellularbars", variableValue: Double(signal) / 4)
        .foregroundStyle(Theme.textDim)
        .help("Netzqualität zum Radio")

      Spacer(minLength: 0)

      // Sendebereitschaft, Spannung, Temperatur, Uhr
      lamp("TX Ready", on: txReady)
      Text(String(format: "%.1f V", MessModell.shared.spannung.map { Double($0) } ?? volts))
        .monospacedDigit()
      Text("\(MessModell.shared.paTemperatur.map { Int($0.rounded()) } ?? celsius) °C")
        .monospacedDigit()
      TimelineView(.periodic(from: .now, by: 1)) { context in
        Text("\(Self.utcFormat.string(from: context.date)) UTC")
          .monospacedDigit()
      }
    }
    .font(Schrift.klein)
    .padding(.horizontal, 12)
    .frame(height: 34)
    .background(Theme.statusBar)
  }

  /// Text in der Mitte: Radio + Firmware, sonst der Verbindungszustand
  private var radioText: String {
    switch verbindung.zustand {
    case .verbunden:
      if let radio = verbindung.radio {
        return "\(RadioVerbindung.name(radio))  v\(radio.packet.version)"
      }
      return "Verbunden"
    case .verbinde: return "Verbinde …"
    case .getrennt: return "Kein Radio – hier klicken"
    case .fehler(let text): return text
    }
  }

  /// Kleine Lampe mit Beschriftung: grün = an, grau = aus
  private func lamp(_ title: String, on: Bool) -> some View {
    HStack(spacing: 5) {
      Circle()
        .fill(on ? Theme.meterValue : Theme.control)
        .overlay(Circle().stroke(Theme.controlBorder))
        .frame(width: 9, height: 9)
      Text(title)
    }
  }
}

/// Popup an der Statusleiste: gefundene Radios, Verbinden / Trennen
struct RadioAuswahl: View {
  private let verbindung = RadioVerbindung.shared

  var body: some View {
    @Bindable var verbindung = self.verbindung
    VStack(alignment: .leading, spacing: Abstand.m) {
      Text("RADIO")
        .font(Schrift.kleinFett)
        .foregroundStyle(Theme.textDim)

      if verbindung.gefundeneRadios.isEmpty {
        Text("Suche im Netz …")
          .foregroundStyle(Theme.textDim)
      }

      ForEach(verbindung.gefundeneRadios) { radio in
        let aktiv = verbindung.radio?.id == radio.id
        HStack(spacing: Abstand.m) {
          VStack(alignment: .leading, spacing: 2) {
            Text(RadioVerbindung.name(radio))
            Text("\(radio.packet.publicIp)  v\(radio.packet.version)  \(radio.packet.status)")
              .font(Schrift.klein)
              .foregroundStyle(Theme.textDim)
          }
          Spacer(minLength: Abstand.l)
          if aktiv {
            Button("Trennen") { Task { await verbindung.trennen() } }
              .buttonStyle(KnopfStil(art: .aus))
          } else {
            Button("Verbinden") { Task { await verbindung.verbinden(radio) } }
              .buttonStyle(KnopfStil(art: .an))
              .disabled(verbindung.zustand == .verbinde)
          }
        }
        .frame(height: Mass.zeilenHoehe)
      }

      Divider()
      Toggle("Beim Start automatisch verbinden", isOn: $verbindung.automatischVerbinden)
        .toggleStyle(.checkbox)
    }
    .font(Schrift.normal)
    .padding(Abstand.l)
    .frame(minWidth: 320)
    .background(Theme.rimuBlock)
  }
}
