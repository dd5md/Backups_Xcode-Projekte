import ApiPackage
import SwiftUI

/// Verbindet die Oberfläche (Flagge, RX-Block, obere Leiste) mit dem Slice im Radio.
/// Lesen: Werte kommen aus dem ApiPackage-Slice. Ändern: Befehl ans Radio, der Wert
/// wird sofort lokal gesetzt (kein Ruckeln) und vom Radio per Status bestätigt.
/// Ohne Verbindung arbeiten die Knöpfe weiter mit ihren eigenen (lokalen) Werten.
extension RadioVerbindung {
  /// Mein Slice: der aktive eigene Slice, sonst der erste eigene
  var meinSlice: Slice? {
    guard istVerbunden else { return nil }
    let eigene = eigeneSlices
    return eigene.first(where: { $0.active }) ?? eigene.first
  }

  /// Alle Slices, die zu xSDR64 gehören (nicht die einer anderen Station)
  var eigeneSlices: [Slice] {
    guard istVerbunden else { return [] }
    return api.slices
      .filter { $0.clientHandle == api.connectionHandle }
      .sorted { ($0.sliceLetter ?? "") < ($1.sliceLetter ?? "") }
  }

  // MARK: - Befehle

  func sende(_ befehl: String) { api.sendTcp(befehl) }

  /// slice set <id> schluessel=wert
  func setze(_ slice: Slice, _ schluessel: String, _ wert: String) {
    sende("slice set \(slice.id) \(schluessel)=\(wert)")
  }

  func setze(_ slice: Slice, _ schluessel: String, _ wert: Bool) {
    setze(slice, schluessel, wert ? "1" : "0")
  }

  /// Frequenz in Hz
  /// autopan: läuft die Frequenz aus dem Bild, schiebt das Radio den Panadapter mit
  func stimme(_ slice: Slice, _ hz: Int, autopan: Bool = false) {
    guard !slice.locked, hz > 0 else { return }
    slice.frequency = hz
    sende("slice tune \(slice.id) " + String(format: "%.6f", Double(hz) / 1_000_000)
          + (autopan ? " autopan=1" : ""))
    // Slice-Option: Panadapter auf den aktiven Slice zentrieren
    if slice.active, SliceOptionen.an(SliceOptionen.panFolgtSliceKey),
       let pan = api.panadapters.first(where: { $0.id == slice.panadapterId }) {
      panMitte(pan, Double(hz), sofort: true)
    }
  }

  /// Abstimmschritt des Slice in Hz (Radio-Einstellung „step“), sonst 100 Hz
  func schritt(_ slice: Slice) -> Int { slice.step > 0 ? slice.step : 100 }

  /// Filterkanten in Hz (wie das Radio sie erwartet, bei LSB negativ)
  func filter(_ slice: Slice, low: Int, high: Int) {
    slice.filterLow = low
    slice.filterHigh = high
    sende("filt \(slice.id) \(low) \(high)")
  }

  func sperre(_ slice: Slice, _ an: Bool) {
    slice.locked = an
    sende("slice \(an ? "lock" : "unlock") \(slice.id)")
  }

  // MARK: - Panadapter: Breite (Zoom) und Mitte (Verschieben)

  private static var letzterPanBefehl = Date.distantPast

  /// Neue Breite begrenzen, sofort anzeigen und ans Radio schicken (höchstens ~25 mal pro Sekunde;
  /// `sofort` am Ende einer Bewegung, damit der letzte Wert sicher ankommt)
  func panBreite(_ pan: Panadapter, _ hz: Double, sofort: Bool) {
    let minBw = pan.minBw > 0 ? pan.minBw : 1_000
    let maxBw = pan.maxBw > 0 ? pan.maxBw : 14_000_000
    let neu = Int(min(Double(maxBw), max(Double(minBw), hz)))
    pan.bandwidth = neu
    guard sofort || Date().timeIntervalSince(Self.letzterPanBefehl) > 0.04 else { return }
    Self.letzterPanBefehl = Date()
    sende("display pan set 0x\(String(pan.id, radix: 16, uppercase: true)) bandwidth="
          + String(format: "%.6f", Double(neu) / 1_000_000))
  }

  /// Neue Mitte des Panadapters (Spektrum verschieben)
  func panMitte(_ pan: Panadapter, _ hz: Double, sofort: Bool) {
    let neu = Int(max(0, hz))
    pan.center = neu
    guard sofort || Date().timeIntervalSince(Self.letzterPanBefehl) > 0.04 else { return }
    Self.letzterPanBefehl = Date()
    sende("display pan set 0x\(String(pan.id, radix: 16, uppercase: true)) center="
          + String(format: "%.6f", Double(neu) / 1_000_000))
    // Slice-Option: Slice bleibt in der Mitte, wenn das Spektrum verschoben wird
    if SliceOptionen.an(SliceOptionen.sliceMitPanKey), let s = meinSlice, s.panadapterId == pan.id,
       !SliceOptionen.an(SliceOptionen.panFolgtSliceKey) {
      s.frequency = neu
      sende("slice tune \(s.id) " + String(format: "%.6f", Double(neu) / 1_000_000))
    }
  }

  // MARK: - Bindungen für die Oberfläche

  /// Ein/Aus-Wert des Slice (z. B. nb, nr, audio_mute)
  func schalter(_ lokal: Binding<Bool>, _ pfad: ReferenceWritableKeyPath<Slice, Bool>, _ schluessel: String) -> Binding<Bool> {
    Binding(
      get: { self.meinSlice?[keyPath: pfad] ?? lokal.wrappedValue },
      set: { neu in
        if let s = self.meinSlice {
          s[keyPath: pfad] = neu
          self.setze(s, schluessel, neu)
        } else {
          lokal.wrappedValue = neu
        }
      })
  }

  /// Zahl 0…100 des Slice als Double für die Regler (z. B. audio_level, nb_level)
  func regler(_ lokal: Binding<Double>, _ pfad: ReferenceWritableKeyPath<Slice, Int>, _ schluessel: String) -> Binding<Double> {
    Binding(
      get: { self.meinSlice.map { Double($0[keyPath: pfad]) } ?? lokal.wrappedValue },
      set: { neu in
        if let s = self.meinSlice {
          let wert = Int(neu.rounded())
          guard wert != s[keyPath: pfad] else { return }  // nur senden, wenn sich etwas ändert
          s[keyPath: pfad] = wert
          self.setze(s, schluessel, String(wert))
        } else {
          lokal.wrappedValue = neu
        }
      })
  }

  /// Ganzzahl des Slice (z. B. rit_freq) für Eingabefelder
  func zahl(_ lokal: Binding<Int>, _ pfad: ReferenceWritableKeyPath<Slice, Int>, _ schluessel: String) -> Binding<Int> {
    Binding(
      get: { self.meinSlice?[keyPath: pfad] ?? lokal.wrappedValue },
      set: { neu in
        if let s = self.meinSlice {
          s[keyPath: pfad] = neu
          self.setze(s, schluessel, String(neu))
        } else {
          lokal.wrappedValue = neu
        }
      })
  }

  /// Text-Wert des Slice (z. B. rxant)
  func text(_ lokal: Binding<String>, _ pfad: ReferenceWritableKeyPath<Slice, String>, _ schluessel: String) -> Binding<String> {
    Binding(
      get: { self.meinSlice?[keyPath: pfad] ?? lokal.wrappedValue },
      set: { neu in
        if let s = self.meinSlice {
          s[keyPath: pfad] = neu
          self.setze(s, schluessel, neu)
        } else {
          lokal.wrappedValue = neu
        }
      })
  }

  /// Filter als (untere Kante, obere Kante) in positiven Hz – bei LSB spiegelt das Radio die Werte
  func filterKanten(_ lokalLow: Binding<Int>, _ lokalHigh: Binding<Int>) -> (low: Binding<Int>, high: Binding<Int>) {
    func istUnten(_ s: Slice) -> Bool { s.mode == "LSB" || s.mode == "DIGL" }
    func kanten(_ s: Slice) -> (Int, Int) {
      istUnten(s) ? (-s.filterHigh, -s.filterLow) : (s.filterLow, s.filterHigh)
    }
    func setzen(_ s: Slice, _ lo: Int, _ hi: Int) {
      if istUnten(s) { filter(s, low: -hi, high: -lo) } else { filter(s, low: lo, high: hi) }
    }
    let low = Binding<Int>(
      get: { self.meinSlice.map { kanten($0).0 } ?? lokalLow.wrappedValue },
      set: { neu in
        if let s = self.meinSlice { setzen(s, neu, kanten(s).1) } else { lokalLow.wrappedValue = neu }
      })
    let high = Binding<Int>(
      get: { self.meinSlice.map { kanten($0).1 } ?? lokalHigh.wrappedValue },
      set: { neu in
        if let s = self.meinSlice { setzen(s, kanten(s).0, neu) } else { lokalHigh.wrappedValue = neu }
      })
    return (low, high)
  }

  // MARK: - Senden (transmit …), Mikrofon, ATU

  /// Zahl 0…100 der Sendeeinstellungen als Double für Regler; `befehl` z. B. "transmit set rfpower"
  func txRegler(_ lokal: Binding<Double>, _ pfad: ReferenceWritableKeyPath<Transmit, Int>, _ befehl: String) -> Binding<Double> {
    Binding(
      get: { self.istVerbunden ? Double(self.api.transmit[keyPath: pfad]) : lokal.wrappedValue },
      set: { neu in
        guard self.istVerbunden else { lokal.wrappedValue = neu; return }
        let wert = Int(neu.rounded())
        guard wert != self.api.transmit[keyPath: pfad] else { return }
        self.api.transmit[keyPath: pfad] = wert
        self.sende("\(befehl)=\(wert)")
      })
  }

  /// Ganzzahl der Sendeeinstellungen (z. B. TX-Filter in Hz)
  func txZahl(_ lokal: Binding<Int>, _ pfad: ReferenceWritableKeyPath<Transmit, Int>, _ befehl: String) -> Binding<Int> {
    Binding(
      get: { self.istVerbunden ? self.api.transmit[keyPath: pfad] : lokal.wrappedValue },
      set: { neu in
        guard self.istVerbunden else { lokal.wrappedValue = neu; return }
        self.api.transmit[keyPath: pfad] = neu
        self.sende("\(befehl)=\(neu)")
      })
  }

  /// Ein/Aus der Sendeeinstellungen; `befehl` liefert den Befehl für an/aus
  func txSchalter(_ lokal: Binding<Bool>, _ pfad: ReferenceWritableKeyPath<Transmit, Bool>,
                  _ befehl: @escaping (Bool) -> String) -> Binding<Bool> {
    Binding(
      get: { self.istVerbunden ? self.api.transmit[keyPath: pfad] : lokal.wrappedValue },
      set: { neu in
        guard self.istVerbunden else { lokal.wrappedValue = neu; return }
        self.api.transmit[keyPath: pfad] = neu
        self.sende(befehl(neu))
      })
  }

  /// Profile vom Radio (type: "mic", "tx", "global")
  func profil(_ typ: String) -> Profile? { istVerbunden ? api.profiles.first { $0.id == typ } : nil }

  /// Auswahl eines Profils: zeigt das aktuelle, laden per „profile <typ> load "<name>"“
  func profilWahl(_ typ: String, _ lokal: Binding<String>) -> Binding<String> {
    Binding(
      get: { self.profil(typ)?.current ?? lokal.wrappedValue },
      set: { neu in
        if let p = self.profil(typ) {
          p.current = neu
          self.sende("profile \(typ) load \"\(neu)\"")
        } else {
          lokal.wrappedValue = neu
        }
      })
  }

  /// Liste der Profile eines Typs (ohne Radio: nur „Default“)
  func profilListe(_ typ: String) -> [String] { profil(typ)?.list.nilWennLeer ?? ["Default"] }

  // MARK: - Hilfen

  /// Amateurfunkband zur Frequenz, z. B. "20 m" (leer außerhalb der Bänder)
  static func band(_ hz: Int) -> String {
    let baender: [(ClosedRange<Int>, String)] = [
      (1_810_000...2_000_000, "160 m"), (3_500_000...3_800_000, "80 m"),
      (5_351_500...5_366_500, "60 m"), (7_000_000...7_200_000, "40 m"),
      (10_100_000...10_150_000, "30 m"), (14_000_000...14_350_000, "20 m"),
      (18_068_000...18_168_000, "17 m"), (21_000_000...21_450_000, "15 m"),
      (24_890_000...24_990_000, "12 m"), (28_000_000...29_700_000, "10 m"),
      (50_000_000...52_000_000, "6 m"),
    ]
    return baender.first { $0.0.contains(hz) }?.1 ?? ""
  }
}

extension Array {
  /// leere Liste → nil (für „Liste vom Radio, sonst Platzhalter“)
  var nilWennLeer: [Element]? { isEmpty ? nil : self }
}
