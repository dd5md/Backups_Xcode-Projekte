import ApiPackage
import SwiftUI

/// App-Einstellungen: xSDR64 → Einstellungen … (⌘,) – wie bei SmartSDR unter dem App-Namen.
/// Hier steht, was xSDR64 selbst betrifft; was im Radio gespeichert wird, steht unter Radio → Radio-Einstellungen.
/// Erste Ausbaustufe – weitere Reiter (Maus/Trackpad, Erweitert, Audio) folgen.
struct AppEinstellungen: View {
  @AppStorage("appEinstellungenReiter") private var reiter = "Allgemein"
  private let reiterNamen = ["Allgemein", "Profile", "Spots", "Über"]

  var body: some View {
    VStack(spacing: 0) {
      HStack(spacing: Abstand.xs) {
        ForEach(reiterNamen, id: \.self) { name in
          Button(name) { reiter = name }
            .buttonStyle(KnopfStil(art: reiter == name ? .an : .aus))
        }
      }
      .padding(Abstand.m)
      .frame(maxWidth: .infinity)
      .background(Theme.bar)

      Group {
        switch reiter {
        case "Profile": ProfileReiter()
        case "Spots": SpotsReiter()
        case "Über": UeberReiter()
        default: AllgemeinAppReiter()
        }
      }
      .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
    }
    .frame(width: 520, height: 360)
    .background(Theme.window)
    .preferredColorScheme(.dark)
  }
}

private struct AllgemeinAppReiter: View {
  @State private var radio = RadioVerbindung.shared
  var body: some View {
    Form {
      Section("Verbindung") {
        Toggle("Beim Start automatisch mit dem letzten Radio verbinden", isOn: $radio.automatischVerbinden)
          .toggleStyle(.checkbox)
        LabeledContent("Stationsname") { Text(RadioVerbindung.stationName) }
      }
    }
    .formStyle(.grouped)
  }
}

private struct ProfileReiter: View {
  @State private var radio = RadioVerbindung.shared
  var body: some View {
    Form {
      Section("Profile") {
        Toggle("Profile automatisch speichern", isOn: Binding(
          get: { radio.radio?.autoSave ?? false },
          set: { radio.sende("profile autosave \($0 ? "on" : "off")") }
        ))
        .toggleStyle(.checkbox)
        .disabled(radio.radio == nil)
        Text("Änderungen (z. B. Leistung, Filter, Mikrofon) werden sofort im aktiven Profil des Radios gesichert. Ohne Haken bleibt das Profil, bis du es selbst speicherst (Radio → Profile → Save).")
          .font(Schrift.klein).foregroundStyle(Theme.textDim)
          .fixedSize(horizontal: false, vertical: true)
        if radio.radio == nil {
          Text("Radio nicht verbunden").font(Schrift.klein).foregroundStyle(Theme.meterYellow)
        }
      }
    }
    .formStyle(.grouped)
  }
}

private struct UeberReiter: View {
  private var version: String {
    let info = Bundle.main.infoDictionary
    return "\(info?["CFBundleShortVersionString"] as? String ?? "?") (\(info?["CFBundleVersion"] as? String ?? "?"))"
  }
  var body: some View {
    VStack(spacing: Abstand.s) {
      Spacer()
      Text("xSDR64").font(Schrift.gross)
      Text("Version \(version)").font(Schrift.normal).foregroundStyle(Theme.textDim)
      Text("FlexRadio-Client für macOS – SSB-Sprache, Audiokette mit VST3").font(Schrift.klein).foregroundStyle(Theme.textDim)
      Text("Grundlage: xSDR6000 / ApiPackage von K3TZR (Douglas Adams)").font(Schrift.klein).foregroundStyle(Theme.textDim)
      Spacer()
    }
    .frame(maxWidth: .infinity)
  }
}

/// Wie bei SmartSDR (Settings → Spots): Memories im Spektrum, Schriftgröße und Position.
/// Dieselben Werte stehen auch unter Disp → MEMORIES.
private struct SpotsReiter: View {
  @AppStorage(MarkenEinstellung.anKey) private var an = true
  @AppStorage(MarkenEinstellung.groesseKey) private var groesse = 11.0
  @AppStorage(MarkenEinstellung.hoeheKey) private var hoehe = 15.0
  @AppStorage(MarkenEinstellung.spotsKey) private var spotsAn = true

  var body: some View {
    Form {
      Section("Memories im Spektrum") {
        Toggle("Memories anzeigen", isOn: $an).toggleStyle(.checkbox)
        LabeledContent("Schriftgröße") {
          HStack {
            Slider(value: $groesse, in: 8...18, step: 1).frame(width: 200)
            Text("\(Int(groesse)) pt").font(Schrift.zahl).frame(width: 44, alignment: .trailing)
          }
        }
        LabeledContent("Position (von oben)") {
          HStack {
            Slider(value: $hoehe, in: 3...90, step: 1).frame(width: 200)
            Text("\(Int(hoehe)) %").font(Schrift.zahl).frame(width: 44, alignment: .trailing)
          }
        }
      }
      Section("DX-Cluster-Spots") {
        Toggle("Spots anzeigen", isOn: $spotsAn).toggleStyle(.checkbox)
        Text("Zeigt die Spots, die im Radio liegen – z. B. von MacLoggerDX („Spots an Flex senden“), SmartSDR oder anderen Programmen. Schriftgröße und Position wie bei den Memories.")
          .font(Schrift.klein).foregroundStyle(Theme.textDim)
          .fixedSize(horizontal: false, vertical: true)
      }
    }
    .formStyle(.grouped)
  }
}
