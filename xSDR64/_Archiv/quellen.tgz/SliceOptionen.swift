import ApiPackage
import Observation
import SwiftUI

/// Slice-Optionen (Menü Slice → Slice-Optionen …), wie bei SmartSDR.
enum SliceOptionen {
  static let sliceMitPanKey = "sliceMitPanadapter"        // Slice bleibt in der Mitte, wenn das Spektrum verschoben wird
  static let panFolgtSliceKey = "panadapterFolgtSlice"    // Panadapter zentriert sich auf den aktiven Slice
  static let txWirdAktivKey = "txSliceWirdAktiv"          // TX-Slice wird immer aktiv
  static let aktivWirdTxKey = "aktiverSliceWirdTx"        // aktiver Slice wird immer TX
  static let syncAnKey = "sliceSyncAn"
  static let syncVonKey = "sliceSyncVon"                  // Buchstabe, z. B. "A"
  static let syncNachKey = "sliceSyncNach"                // Buchstabe, z. B. "B"
  static let syncOffsetKey = "sliceSyncOffset"            // Hz

  static func an(_ key: String) -> Bool { UserDefaults.standard.bool(forKey: key) }
}

/// Beobachtet die Slices und setzt die gewählten Kopplungen um (TX ↔ aktiv, Synchronisation)
@MainActor
final class SliceKopplung {
  static let shared = SliceKopplung()
  private var letzterAktiv: UInt32?
  private var letzterTx: UInt32?
  private var letzteSyncHz: Int?

  func beobachten() {
    withObservationTracking {
      for s in RadioVerbindung.shared.eigeneSlices { _ = s.active; _ = s.txEnabled; _ = s.frequency }
    } onChange: {
      Task { @MainActor in
        SliceKopplung.shared.pruefen()
        SliceKopplung.shared.beobachten()
      }
    }
  }

  private func pruefen() {
    let radio = RadioVerbindung.shared
    let slices = radio.eigeneSlices
    guard radio.istVerbunden, !slices.isEmpty else { return }
    let aktiv = slices.first { $0.active }
    let tx = slices.first { $0.txEnabled }

    // TX-Slice wurde gewechselt → aktiv machen
    if SliceOptionen.an(SliceOptionen.txWirdAktivKey), let tx, tx.id != letzterTx, !tx.active {
      radio.sende("slice set \(tx.id) active=1")
    }
    // aktiver Slice wurde gewechselt → TX machen
    if SliceOptionen.an(SliceOptionen.aktivWirdTxKey), let aktiv, aktiv.id != letzterAktiv, !aktiv.txEnabled {
      radio.sende("slice set \(aktiv.id) tx=1")
    }
    letzterAktiv = aktiv?.id
    letzterTx = tx?.id

    // Synchronisation: Slice „nach“ folgt Slice „von“ mit Versatz
    let d = UserDefaults.standard
    if d.bool(forKey: SliceOptionen.syncAnKey),
       let von = slices.first(where: { $0.sliceLetter == d.string(forKey: SliceOptionen.syncVonKey) }),
       let nach = slices.first(where: { $0.sliceLetter == d.string(forKey: SliceOptionen.syncNachKey) }),
       von.id != nach.id {
      let ziel = von.frequency + d.integer(forKey: SliceOptionen.syncOffsetKey)
      if nach.frequency != ziel, von.frequency != letzteSyncHz || nach.frequency != ziel {
        radio.stimme(nach, ziel)
      }
      letzteSyncHz = von.frequency
    }
  }
}

struct SliceOptionenFenster: View {
  @State private var radio = RadioVerbindung.shared
  @AppStorage(SliceOptionen.sliceMitPanKey) private var sliceMitPan = false
  @AppStorage(SliceOptionen.panFolgtSliceKey) private var panFolgtSlice = false
  @AppStorage(SliceOptionen.txWirdAktivKey) private var txWirdAktiv = false
  @AppStorage(SliceOptionen.aktivWirdTxKey) private var aktivWirdTx = false
  @AppStorage(SliceOptionen.syncAnKey) private var syncAn = false
  @AppStorage(SliceOptionen.syncVonKey) private var syncVon = "A"
  @AppStorage(SliceOptionen.syncNachKey) private var syncNach = "B"
  @AppStorage(SliceOptionen.syncOffsetKey) private var syncOffset = 0

  private var buchstaben: [String] {
    let da = radio.eigeneSlices.compactMap(\.sliceLetter)
    return da.isEmpty ? ["A", "B"] : da
  }

  var body: some View {
    Form {
      Section("Slice / Panadapter") {
        Toggle("Slice-Frequenz mit dem Panadapter mitziehen (Slice bleibt in der Mitte)", isOn: $sliceMitPan)
        Toggle("Panadapter auf den aktiven Slice zentrieren", isOn: $panFolgtSlice)
      }
      Section("TX-Slice") {
        Toggle("TX-Slice immer zum aktiven Slice machen", isOn: $txWirdAktiv)
        Toggle("Aktiven Slice immer zum TX-Slice machen", isOn: $aktivWirdTx)
      }
      Section("Slice-Synchronisation") {
        HStack {
          Toggle("Slice", isOn: $syncAn)
          Picker("", selection: $syncVon) { ForEach(buchstaben, id: \.self) { Text($0).tag($0) } }
            .labelsHidden().frame(width: 60)
          Text("mit")
          Picker("", selection: $syncNach) { ForEach(buchstaben, id: \.self) { Text($0).tag($0) } }
            .labelsHidden().frame(width: 60)
          Text("Versatz (Hz):")
          TextField("", value: $syncOffset, format: .number)
            .textFieldStyle(.roundedBorder).frame(width: 80)
        }
        Text("Der zweite Slice folgt dem ersten mit dem eingestellten Versatz.")
          .font(Schrift.klein).foregroundStyle(Theme.textDim)
      }
    }
    .toggleStyle(.checkbox)
    .formStyle(.grouped)
    .frame(width: 520, height: 400)
    .background(Theme.window)
  }
}
