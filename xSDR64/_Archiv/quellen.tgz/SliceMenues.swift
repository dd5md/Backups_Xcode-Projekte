import ApiPackage
import SwiftUI

/// Menüs „Slice“ und „Panadapter“ in der Menüleiste (wie SmartSDR).
/// Die Hauptanzeige folgt dem aktiven Slice – wer hier einen anderen Slice/Panadapter wählt,
/// sieht dessen Spektrum (z. B. bei Full Duplex mit zwei Panadaptern).
struct SliceMenue: Commands {
  var body: some Commands {
    CommandMenu("Slice") { SliceMenueInhalt() }
    CommandMenu("Panadapter") { PanMenueInhalt() }
  }
}

private struct SliceMenueInhalt: View {
  @State private var radio = RadioVerbindung.shared

  var body: some View {
    let slices = radio.eigeneSlices
    if slices.isEmpty {
      Text(radio.istVerbunden ? "Keine Slices" : "Radio nicht verbunden")
    }
    ForEach(slices, id: \.id) { s in
      Toggle(SliceMenueInhalt.titel(s), isOn: Binding(
        get: { s.active },
        set: { _ in radio.sende("slice set \(s.id) active=1") }
      ))
    }
    Divider()
    Button("Neuen Slice erstellen") { neuerSlice() }
      .disabled(!radio.istVerbunden || radio.meinSlice == nil)
    Button("Aktiven Slice schließen") {
      if let s = radio.meinSlice { radio.sende("slice remove \(s.id)") }
    }
    .disabled(radio.eigeneSlices.count <= 1)
    Divider()
    FensterOeffnen(titel: "Slice-Optionen …", id: "sliceoptionen")
  }

  /// „A: 3.655 LSB [TX]“
  static func titel(_ s: Slice) -> String {
    let mhz = String(format: "%.3f", Double(s.frequency) / 1_000_000)
    return "\(s.sliceLetter ?? "?"): \(mhz) \(s.mode)" + (s.txEnabled ? " [TX]" : "")
  }

  /// Neuer Slice im Panadapter des aktiven Slice, 5 kHz daneben (wie +RX)
  private func neuerSlice() {
    guard let s = radio.meinSlice else { return }
    let hz = Double(s.frequency + 5_000) / 1_000_000
    radio.sende("slice create pan=0x\(String(s.panadapterId, radix: 16, uppercase: true)) freq=\(String(format: "%.6f", hz)) mode=\(s.mode)")
  }
}

private struct PanMenueInhalt: View {
  @State private var radio = RadioVerbindung.shared

  var body: some View {
    let pans = eigenePans
    if pans.isEmpty {
      Text(radio.istVerbunden ? "Keine Panadapter" : "Radio nicht verbunden")
    }
    ForEach(Array(pans.enumerated()), id: \.element.id) { nr, p in
      let slices = radio.eigeneSlices.filter { $0.panadapterId == p.id }
      Toggle(titel(nr + 1, p, slices), isOn: Binding(
        get: { radio.meinSlice?.panadapterId == p.id },
        set: { _ in
          // Panadapter wählen = seinen (ersten) Slice aktiv machen – die Anzeige folgt
          if let s = slices.first { radio.sende("slice set \(s.id) active=1") }
        }
      ))
      .disabled(slices.isEmpty)
    }
    Divider()
    Button("Neuen Panadapter erstellen") {
      radio.sende("display panafall create x=1024 y=700")
    }
    .disabled(!radio.istVerbunden)
  }

  private var eigenePans: [Panadapter] {
    radio.api.panadapters
      .filter { $0.clientHandle == radio.api.connectionHandle }
      .sorted { $0.id < $1.id }
  }

  /// „1: 3.685 (A) [TX]“
  private func titel(_ nr: Int, _ p: Panadapter, _ slices: [Slice]) -> String {
    let mhz = String(format: "%.3f", Double(p.center) / 1_000_000)
    let buchstaben = slices.compactMap(\.sliceLetter).joined(separator: ",")
    return "\(nr): \(mhz)" + (buchstaben.isEmpty ? "" : " (\(buchstaben))")
      + (slices.contains { $0.txEnabled } ? " [TX]" : "")
  }
}

private struct FensterOeffnen: View {
  @Environment(\.openWindow) private var openWindow
  let titel: String
  let id: String
  var body: some View { Button(titel) { openWindow(id: id) } }
}
