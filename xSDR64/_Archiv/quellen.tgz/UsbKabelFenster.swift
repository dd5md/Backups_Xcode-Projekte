import ApiPackage
import SwiftUI

/// Fenster „USB Cables“ wie bei SmartSDR: am Radio angesteckte USB-Kabel
/// (z. B. CAT zur ACOM-Endstufe) mit Name, Seriennummer, Ein/Aus, Logging, Typ und Details.
struct UsbKabelFenster: View {
  @State private var radio = RadioVerbindung.shared
  @State private var auswahl: String?
  @State private var details: String?
  @State private var loeschen: String?

  static let typen = ["cat", "bcd", "bit", "ldpa"]

  private var kabel: [UsbCable] { radio.api.usbCables.sorted { $0.name.lowercased() < $1.name.lowercased() } }

  var body: some View {
    VStack(spacing: 0) {
      HStack {
        Spacer()
        Button {
          loeschen = auswahl
        } label: {
          Image(systemName: "trash")
        }
        .help("Kabel aus der Liste des Radios entfernen")
        .buttonStyle(KnopfStil())
        .disabled(auswahl == nil)
      }
      .padding(Abstand.m)
      .background(Theme.bar)

      if radio.istVerbunden {
        Table(kabel, selection: $auswahl) {
          TableColumn("Name") { k in NameFeld(kabel: k) }.width(min: 100, ideal: 150)
          TableColumn("Serial") { k in
            HStack(spacing: 4) {
              Circle().fill(k.pluggedIn ? Theme.meterValue : Theme.ledOff).frame(width: 7, height: 7)
                .help(k.pluggedIn ? "eingesteckt" : "nicht eingesteckt")
              Text(k.id).font(Schrift.zahl)
            }
          }
          .width(min: 100, ideal: 120)
          TableColumn("Enabled") { k in
            haken(k.enable) { radio.sende(UsbCable.set(id: k.id, property: .enable, value: $0 ? "1" : "0")) }
          }
          .width(60)
          TableColumn("Logging") { k in
            haken(k.usbLog) { radio.sende(UsbCable.set(id: k.id, property: .usbLog, value: $0 ? "1" : "0")) }
          }
          .width(60)
          TableColumn("Type") { k in
            Picker("", selection: Binding(
              get: { k.type },
              set: { radio.sende(UsbCable.set(id: k.id, property: .type, value: $0)) }
            )) {
              if !Self.typen.contains(k.type) { Text(k.type.isEmpty ? "–" : k.type.uppercased()).tag(k.type) }
              ForEach(Self.typen, id: \.self) { Text($0.uppercased()).tag($0) }
            }
            .labelsHidden()
          }
          .width(min: 70, ideal: 80)
          TableColumn("") { k in
            Button("Details") { details = k.id }.buttonStyle(KnopfStil())
          }
          .width(70)
        }
        .tableStyle(.inset(alternatesRowBackgrounds: true))
        .scrollContentBackground(.hidden)
      } else {
        Spacer()
        Text("Radio nicht verbunden").font(Schrift.normal).foregroundStyle(Theme.textDim)
        Spacer()
      }
    }
    .frame(minWidth: 600, minHeight: 300)
    .background(Theme.window)
    .sheet(item: Binding(get: { details.map(KabelId.init) }, set: { details = $0?.id })) { id in
      if let k = radio.api.usbCables.first(where: { $0.id == id.id }) {
        UsbKabelDetails(kabel: k) { details = nil }
      }
    }
    .confirmationDialog("Kabel „\(loeschen ?? "")“ aus der Liste des Radios entfernen?",
                        isPresented: Binding(get: { loeschen != nil }, set: { if !$0 { loeschen = nil } }),
                        titleVisibility: .visible) {
      Button("Entfernen", role: .destructive) {
        if let id = loeschen { radio.sende("usb_cable remove \(id)") }
        auswahl = nil
      }
      Button("Abbrechen", role: .cancel) {}
    }
  }

  private func haken(_ wert: Bool, _ setzen: @escaping (Bool) -> Void) -> some View {
    Toggle("", isOn: Binding(get: { wert }, set: setzen))
      .toggleStyle(.checkbox)
      .labelsHidden()
      .frame(maxWidth: .infinity)
  }
}

private struct KabelId: Identifiable { let id: String }

/// Name zum Bearbeiten – Leerzeichen schickt das Radio als 0x7F
private struct NameFeld: View {
  let kabel: UsbCable
  @State private var text = ""
  @FocusState private var fokus: Bool

  private var anzeige: String { kabel.name.replacingOccurrences(of: "\u{7F}", with: " ") }

  var body: some View {
    TextField("", text: $text)
      .textFieldStyle(.plain)
      .font(Schrift.normal)
      .focused($fokus)
      .onAppear { text = anzeige }
      .onChange(of: kabel.name) { _, _ in if !fokus { text = anzeige } }
      .onSubmit(uebernehmen)
      .onChange(of: fokus) { _, jetzt in if !jetzt { uebernehmen() } }
  }

  private func uebernehmen() {
    let neu = text.trimmingCharacters(in: .whitespaces)
    guard !neu.isEmpty, neu != anzeige else { text = anzeige; return }
    RadioVerbindung.shared.sende(UsbCable.set(id: kabel.id, property: .name,
                                              value: neu.replacingOccurrences(of: " ", with: "\u{7F}")))
  }
}

/// Details eines Kabels – für CAT: serielle Einstellungen und Frequenzquelle
private struct UsbKabelDetails: View {
  let kabel: UsbCable
  let fertig: () -> Void
  private var radio: RadioVerbindung { RadioVerbindung.shared }

  var body: some View {
    VStack(alignment: .leading, spacing: Abstand.m) {
      Text("\(kabel.name.replacingOccurrences(of: "\u{7F}", with: " ")) – \(kabel.type.uppercased())")
        .font(Schrift.gross)
      Text("Seriennummer \(kabel.id)").font(Schrift.klein).foregroundStyle(Theme.textDim)
      Divider()

      if kabel.type == "cat" {
        Grid(alignment: .leading, horizontalSpacing: Abstand.m, verticalSpacing: Abstand.s) {
          zeile("Geschwindigkeit", .speed, String(kabel.speed),
                ["300", "600", "1200", "2400", "4800", "9600", "14400", "19200", "38400", "57600", "115200"])
          zeile("Datenbits", .dataBits, String(kabel.dataBits), ["7", "8"])
          zeile("Parität", .parity, kabel.parity, ["none", "odd", "even", "mark", "space"])
          zeile("Stoppbits", .stopBits, String(kabel.stopBits), ["1", "2"])
          zeile("Flusssteuerung", .flowControl, kabel.flowControl, ["none", "rts_cts", "dtr_dsr", "xon_xoff"])
          zeile("Frequenz von", .source, kabel.source, ["tx_slice", "active_slice", "tx_ant", "rx_ant", "slice"])
          if kabel.source == "slice" {
            zeile("Slice", .sourceSlice, String(kabel.sourceSlice), ["0", "1", "2", "3", "4", "5", "6", "7"],
                  anzeige: { String(UnicodeScalar(UInt8(65 + (Int($0) ?? 0)))) })
          }
          GridRow {
            Text("Auto-Report").foregroundStyle(Theme.textDim)
            Toggle("", isOn: Binding(
              get: { kabel.autoReport },
              set: { radio.sende(UsbCable.set(id: kabel.id, property: .autoReport, value: $0 ? "1" : "0")) }
            ))
            .toggleStyle(.checkbox).labelsHidden()
          }
        }
        .font(Schrift.normal)
      } else {
        Text("Details für Kabeltyp \(kabel.type.uppercased()) sind noch nicht eingebaut.")
          .font(Schrift.normal).foregroundStyle(Theme.textDim)
      }

      HStack {
        Spacer()
        Button("Fertig", action: fertig).keyboardShortcut(.defaultAction)
      }
    }
    .padding(Abstand.l)
    .frame(width: 380)
  }

  private func zeile(_ titel: String, _ eigenschaft: UsbCable.Property, _ wert: String, _ werte: [String],
                     anzeige: @escaping (String) -> String = { $0 }) -> some View {
    GridRow {
      Text(titel).foregroundStyle(Theme.textDim)
      Picker("", selection: Binding(
        get: { wert },
        set: { radio.sende(UsbCable.set(id: kabel.id, property: eigenschaft, value: $0)) }
      )) {
        if !werte.contains(wert) { Text(wert.isEmpty ? "–" : anzeige(wert)).tag(wert) }
        ForEach(werte, id: \.self) { Text(anzeige($0)).tag($0) }
      }
      .labelsHidden()
      .frame(width: 160)
    }
  }
}
