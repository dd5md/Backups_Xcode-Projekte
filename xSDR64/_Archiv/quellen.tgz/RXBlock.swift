import ApiPackage
import SwiftUI

/// Inhalt des RX-Blocks: Slice, Antenne, TX, Mode, Frequenz, Lautstärke,
/// Balance, Squelch, AGC, NB/NR/ANF, DAX-Kanal, Filter, RIT/XIT
/// 01.10.2026: auf RimuSDR-Stil umgestellt (Design-Vorgabe)
struct RXBlock: View {
  /// Betriebsarten – bewusst ohne Digimodes (DIGU, DIGL, RTTY)
  enum Mode: String, CaseIterable, Identifiable {
    case usb = "USB", lsb = "LSB", am = "AM", sam = "SAM", fm = "FM"
    var id: String { rawValue }
  }
  enum AGC: String, CaseIterable, Identifiable {
    case off = "Off", slow = "Slow", med = "Med", fast = "Fast"
    var id: String { rawValue }
  }

  /// Breite der linken Spalte – gleich wie in TX, MIC und PHONE
  private let spalte: CGFloat = 78

  // Ersatzwerte, solange kein Radio verbunden ist – verbunden kommen alle Werte vom Radio
  @State private var slice = "A"
  @State private var antenna = "ANT1"
  @State private var txSlice = "A"  // welcher Slice sendet – immer nur einer
  @State private var mode: Mode = .usb
  @State private var frequency = 14_200_000  // Hz
  @State private var lockOn = false
  @State private var muteOn = false
  @State private var volume = 50.0
  @State private var balance = 50.0  // 0 = links, 50 = Mitte, 100 = rechts
  @State private var sqlOn = false
  @State private var sqlLevel = 20.0
  @State private var agc: AGC = .slow
  @State private var agcThreshold = 65.0
  @State private var wnbOn = false
  @State private var wnbLevel = 50.0
  @State private var showDSP = false  // Popup mit den Reglern offen?
  @State private var nbOn = false
  @State private var nbLevel = 50.0
  @State private var nrOn = false
  @State private var nrLevel = 50.0
  @State private var anfOn = false
  @State private var anfLevel = 50.0
  @State private var daxChannel = 0  // 0 = Off, sonst Kanal 1–8
  @State private var filterLow = 100  // Hz – untere Filterkante
  @State private var filterWidth = 2700  // Hz – gewählte Filterbreite
  @State private var ritOn = false
  @State private var ritOffset = 0  // Hz
  @State private var xitOn = false
  @State private var xitOffset = 0  // Hz

  /// Verbindung zum Radio – ohne Verbindung gelten die lokalen Werte oben
  private let radio = RadioVerbindung.shared

  /// Filterbreiten für SSB – wie die Filtertasten in SmartSDR
  private let filterWidths = [1600, 1800, 2100, 2400, 2700, 2900, 3300, 4000]

  var body: some View {
    let s = radio.meinSlice
    let kanten = radio.filterKanten($filterLow, Binding(get: { filterLow + filterWidth }, set: { filterWidth = $0 - filterLow }))
    let breite = kanten.high.wrappedValue - kanten.low.wrappedValue
    VStack(spacing: 0) {
      // Slice – Antenne
      HStack(spacing: Abstand.s) {
        RimuPicker(selection: sliceWahl, options: sliceBuchstaben) { "Slice \($0)" }
        RimuPicker(selection: radio.text($antenna, \.rxAnt, "rxant"),
                   options: s.map { $0.rxAntList.isEmpty ? ["ANT1", "ANT2"] : $0.rxAntList } ?? ["ANT1", "ANT2", "RX_A", "RX_B"]) { $0 }
      }
      .frame(height: Mass.zeilenHoehe)

      // TX (rot = Sende-Slice) – Mode
      HStack(spacing: Abstand.s) {
        Button("TX") {
          if let s { s.txEnabled = true; radio.setze(s, "tx", true) } else { txSlice = slice }
        }
        .buttonStyle(KnopfStil(art: (s?.txEnabled ?? (txSlice == slice)) ? .rot : .aus, breite: spalte))
        RimuPicker(selection: modeWahl, options: Mode.allCases) { $0.rawValue }
      }
      .frame(height: Mass.zeilenHoehe)

      // Frequenz groß, daneben Schloss
      HStack(spacing: Abstand.s) {
        Text(Self.format(s?.frequency ?? frequency))
          .font(Schrift.frequenz)
        Spacer(minLength: 0)
        Button("LOCK") {
          if let s { radio.sperre(s, !s.locked) } else { lockOn.toggle() }
        }
        .buttonStyle(KnopfStil(art: (s?.locked ?? lockOn) ? .an : .aus, breite: 60))
      }
      .frame(height: Mass.zeilenHoehe + Abstand.s)

      // Lautstärke, Balance, Squelch, AGC
      let mute = radio.schalter($muteOn, \.audioMute, "audio_mute")
      ElementReglerZeile(value: radio.regler($volume, \.audioGain, "audio_level")) {
        Button("MUTE") { mute.wrappedValue.toggle() }
          .buttonStyle(KnopfStil(art: mute.wrappedValue ? .rot : .aus, breite: spalte))
      }
      ReglerZeile(label: "Balance:", value: radio.regler($balance, \.audioPan, "audio_pan"))
      let sql = radio.schalter($sqlOn, \.squelchEnabled, "squelch")
      ElementReglerZeile(value: radio.regler($sqlLevel, \.squelchLevel, "squelch_level")) {
        Button("SQL") { sql.wrappedValue.toggle() }
          .buttonStyle(KnopfStil(art: sql.wrappedValue ? .an : .aus, breite: spalte))
      }
      ElementReglerZeile(value: radio.regler($agcThreshold, \.agcThreshold, "agc_threshold")) {
        RimuPicker(selection: agcWahl, options: AGC.allCases) { $0.rawValue }
      }

      Furche().padding(.vertical, Abstand.xs)

      // Störunterdrückung: nur Schalter – die Regler stecken im OPT-Popup
      let nb = radio.schalter($nbOn, \.nbEnabled, "nb")
      let nr = radio.schalter($nrOn, \.nrEnabled, "nr")
      let anf = radio.schalter($anfOn, \.anfEnabled, "anf")
      HStack(spacing: Abstand.xs) {
        Button("NB") { nb.wrappedValue.toggle() }.buttonStyle(KnopfStil(art: nb.wrappedValue ? .an : .aus, breite: 54))
        Button("NR") { nr.wrappedValue.toggle() }.buttonStyle(KnopfStil(art: nr.wrappedValue ? .an : .aus, breite: 54))
        Button("ANF") { anf.wrappedValue.toggle() }.buttonStyle(KnopfStil(art: anf.wrappedValue ? .an : .aus, breite: 54))
        Spacer(minLength: 0)
        Button("OPT") { showDSP.toggle() }
          .buttonStyle(KnopfStil(art: showDSP ? .an : .aus, breite: 54))
          .popover(isPresented: $showDSP, arrowEdge: .top) {
            VStack(spacing: 0) {
              dspRow("WNB", isOn: radio.schalter($wnbOn, \.wnbEnabled, "wnb"),
                     value: radio.regler($wnbLevel, \.wnbLevel, "wnb_level"))
              dspRow("NB", isOn: nb, value: radio.regler($nbLevel, \.nbLevel, "nb_level"))
              dspRow("NR", isOn: nr, value: radio.regler($nrLevel, \.nrLevel, "nr_level"))
              dspRow("ANF", isOn: anf, value: radio.regler($anfLevel, \.anfLevel, "anf_level"))
            }
            .font(Schrift.normal)
            .padding(Abstand.m)
            .frame(width: 280)
          }
      }
      .frame(height: Mass.zeilenHoehe)

      // DAX-Kanal: Empfangsaudio dieses Slice nach außen geben
      HStack(spacing: Abstand.s) {
        Text("DAX:")
          .frame(width: spalte, alignment: .leading)
        // mit dem Radio verbunden: „slice set <id> dax=<n>“ (vorher nur lokale Anzeige)
        RimuPicker(selection: Binding(
          get: { radio.meinSlice?.daxChannel ?? daxChannel },
          set: { neu in
            if let s = radio.meinSlice { s.daxChannel = neu; radio.setze(s, "dax", String(neu)) } else { daxChannel = neu }
          }), options: Array(0...8)) { $0 == 0 ? "Off" : "Kanal \($0)" }
      }
      .frame(height: Mass.zeilenHoehe)

      Furche().padding(.vertical, Abstand.xs)

      // Filter: Kanten + Tasten für die Breite
      HStack(spacing: Abstand.s) {
        Text("Filter:")
          .frame(width: spalte, alignment: .leading)
        Spacer(minLength: 0)
        Text("\(kanten.low.wrappedValue) – \(kanten.high.wrappedValue) Hz")
          .font(Schrift.zahl)
      }
      .frame(height: Mass.zeilenHoehe)
      LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: Abstand.xs), count: 4),
                spacing: Abstand.xs) {
        ForEach(filterWidths, id: \.self) { width in
          Button(Self.kHz(width)) { kanten.high.wrappedValue = kanten.low.wrappedValue + width }
            .buttonStyle(KnopfStil(art: breite == width ? .an : .aus, breite: 54))
        }
      }

      Furche().padding(.vertical, Abstand.s)

      // RIT / XIT: Knopf + Versatz in Hz
      offsetRow("RIT", isOn: radio.schalter($ritOn, \.ritEnabled, "rit_on"),
                offset: radio.zahl($ritOffset, \.ritOffset, "rit_freq"))
      offsetRow("XIT", isOn: radio.schalter($xitOn, \.xitEnabled, "xit_on"),
                offset: radio.zahl($xitOffset, \.xitOffset, "xit_freq"))
    }
    .font(Schrift.normal)
    .padding(Abstand.s)
    .foregroundStyle(Theme.text)
  }

  // MARK: - Auswahl Slice / Mode / AGC (mit Radio verbunden)

  /// Buchstaben der eigenen Slices (ohne Radio: A–D)
  private var sliceBuchstaben: [String] {
    let eigene = radio.eigeneSlices.compactMap { $0.sliceLetter }
    return eigene.isEmpty ? ["A", "B", "C", "D"] : eigene
  }

  /// Slice wählen = im Radio aktiv setzen
  private var sliceWahl: Binding<String> {
    Binding(
      get: { radio.meinSlice?.sliceLetter ?? slice },
      set: { neu in
        if let s = radio.eigeneSlices.first(where: { $0.sliceLetter == neu }) {
          s.active = true
          radio.setze(s, "active", true)
        } else {
          slice = neu
        }
      })
  }

  private var modeWahl: Binding<Mode> {
    Binding(
      get: { radio.meinSlice.flatMap { Mode(rawValue: $0.mode) } ?? mode },
      set: { neu in
        if let s = radio.meinSlice { s.mode = neu.rawValue; radio.setze(s, "mode", neu.rawValue) } else { mode = neu }
      })
  }

  /// Radio meldet agc_mode klein geschrieben (off, slow, med, fast)
  private var agcWahl: Binding<AGC> {
    Binding(
      get: { radio.meinSlice.flatMap { s in AGC.allCases.first { $0.rawValue.lowercased() == s.agcMode.lowercased() } } ?? agc },
      set: { neu in
        if let s = radio.meinSlice {
          s.agcMode = neu.rawValue.lowercased()
          radio.setze(s, "agc_mode", neu.rawValue.lowercased())
        } else {
          agc = neu
        }
      })
  }

  /// Zeile im OPT-Popup: Name – Regler – Wert – Häkchen (ein/aus)
  private func dspRow(_ title: String, isOn: Binding<Bool>, value: Binding<Double>) -> some View {
    HStack(spacing: Abstand.s) {
      Text(title)
        .frame(width: 40, alignment: .leading)
      RimuSlider(value: value)
      Text("\(Int(value.wrappedValue))")
        .font(Schrift.zahl)
        .frame(width: 30, alignment: .trailing)
      Toggle("", isOn: isOn)
        .toggleStyle(.checkbox)
        .labelsHidden()
    }
    .frame(height: Mass.zeilenHoehe)
  }

  /// Zeile: Knopf – Versatz in Hz (zum Eintippen, mit Pfeilen)
  private func offsetRow(_ title: String, isOn: Binding<Bool>, offset: Binding<Int>) -> some View {
    HStack(spacing: Abstand.s) {
      Button(title) { isOn.wrappedValue.toggle() }
        .buttonStyle(KnopfStil(art: isOn.wrappedValue ? .an : .aus, breite: spalte))
      Spacer(minLength: 0)
      HzEingabe(value: offset, range: -9990...9990, vorzeichen: true, breite: 120)
    }
    .frame(height: Mass.zeilenHoehe)
  }

  /// 2700 → "2.7K"
  static func kHz(_ hz: Int) -> String {
    String(format: "%.1fK", Double(hz) / 1000)
  }

  /// 14200000 → "14.200.000"
  static func format(_ hz: Int) -> String {
    let mhz = hz / 1_000_000
    let khz = (hz / 1_000) % 1_000
    let rest = hz % 1_000
    return "\(mhz)." + String(format: "%03d", khz) + "." + String(format: "%03d", rest)
  }
}
