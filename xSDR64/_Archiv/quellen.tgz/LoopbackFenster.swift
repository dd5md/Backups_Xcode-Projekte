import SwiftUI

/// Menü „Radio“ in der Menüleiste (wie bei SmartSDR das erste Menü nach dem App-Namen).
/// Weitere Einstellungsfenster (Radio-Einstellungen, Profile, TX Band Settings …) kommen hier dazu.
struct RadioMenue: Commands {
  var body: some Commands {
    CommandMenu("Radio") {
      FensterKnopf(titel: "Radio-Einstellungen …", id: "radioeinstellungen")
      Divider()
      FensterKnopf(titel: "Audio-Loopback …", id: "loopback")
      FensterKnopf(titel: "Klangaufbereitung im Radio …", id: "klang")
      FensterKnopf(titel: "USB Cables …", id: "usbkabel")
      FensterKnopf(titel: "RC-28 …", id: "rc28")
      FensterKnopf(titel: "TX Band Settings …", id: "txband")
      Divider()
      Menu("Profile") {
        ForEach(ProfilArt.allCases) { FensterKnopf(titel: $0.menueName, id: $0.fensterId) }
      }
    }
  }
}

private struct FensterKnopf: View {
  @Environment(\.openWindow) private var openWindow
  let titel: String
  let id: String
  var body: some View { Button(titel) { openWindow(id: id) } }
}

/// Fenster „Audio-Loopback“ – Ton mit festem Pegel in ein Audiogerät (für Aufnahmen),
/// angelehnt an „DAX Streaming settings“ von SmartSDR.
struct LoopbackFenster: View {
  @State private var loop = Loopback.shared
  @State private var radio = RadioVerbindung.shared

  var body: some View {
    VStack(alignment: .leading, spacing: Abstand.m) {
      HStack {
        Text("AUDIO-LOOPBACK").font(Schrift.kleinFett).foregroundStyle(Theme.textDim)
        Spacer()
        Circle().fill(loop.laeuft ? Theme.meterValue : Theme.ledOff).frame(width: 9, height: 9)
      }

      Toggle("Loopback einschalten (bleibt auch nach Neustart an)", isOn: $loop.aktiv)
        .font(Schrift.normal)

      zeile("Quelle") {
        Picker("", selection: $loop.quelle) {
          ForEach(Loopback.Quelle.allCases) { Text($0.name).tag($0) }
        }
        .labelsHidden()
      }

      zeile("Ausgabe an") {
        Picker("", selection: $loop.ausgabeUID) {
          if !loop.ausgaben.contains(where: { $0.uid == loop.ausgabeUID }) {
            Text("(nicht gefunden)").tag(loop.ausgabeUID)
          }
          ForEach(loop.ausgaben, id: \.uid) { Text($0.name).tag($0.uid) }
        }
        .labelsHidden()
      }

      zeile("DAX-Kanal") {
        Picker("", selection: $loop.kanal) {
          Text("Automatisch (Slice mit DAX)").tag(0)
          ForEach(1...4, id: \.self) { Text("DAX \($0)").tag($0) }
        }
        .labelsHidden()
      }
      .disabled(!loop.quelle.mitEmpfang)

      zeile("Pegel RX") {
        Slider(value: $loop.rxPegel, in: 0...30, step: 1)
        Text("+\(Int(loop.rxPegel)) dB").font(Schrift.zahl).foregroundStyle(Theme.textDim).frame(width: 48, alignment: .trailing)
      }
      .disabled(!loop.quelle.mitEmpfang)

      if !loop.treiberInstalliert {
        Text("Treiber „xSDR64 Loopback“ ist nicht installiert.")
          .font(Schrift.klein).foregroundStyle(Theme.meterYellow)
      }

      Divider()

      pegel("Empfang", loop.pegelRx, an: loop.quelle.mitEmpfang)
      pegel("Sendeton", loop.pegelTx, an: loop.quelle.mitSendeton)

      Text(radio.istVerbunden ? "Status: \(loop.status)" : "Status: Radio nicht verbunden")
        .font(Schrift.klein).foregroundStyle(Theme.textDim)
        .lineLimit(2)

      Text("Fester Pegel – unabhängig von der Lautstärke oben. Im Aufnahmeprogramm (z. B. QuickTime, OBS) „xSDR64 Loopback“ als Mikrofon wählen.")
        .font(Schrift.klein).foregroundStyle(Theme.textDim)
        .fixedSize(horizontal: false, vertical: true)
    }
    .padding(Abstand.l)
    .frame(width: 380)
    .background(Theme.window)
  }

  private func zeile<Inhalt: View>(_ titel: String, @ViewBuilder _ inhalt: () -> Inhalt) -> some View {
    HStack {
      Text(titel).font(Schrift.normal).foregroundStyle(Theme.textDim).frame(width: 80, alignment: .leading)
      inhalt()
    }
  }

  private func pegel(_ titel: String, _ db: Float, an: Bool) -> some View {
    HStack(spacing: Abstand.s) {
      Text(titel).font(Schrift.klein).foregroundStyle(an ? Theme.text : Theme.textDim)
        .frame(width: 80, alignment: .leading)
      GeometryReader { g in
        let anteil = CGFloat(max(0, min(1, (db + 60) / 60)))
        ZStack(alignment: .leading) {
          RoundedRectangle(cornerRadius: 2).fill(Theme.ledOff)
          RoundedRectangle(cornerRadius: 2)
            .fill(db > -3 ? Theme.meterRed : db > -12 ? Theme.meterYellow : Theme.meterValue)
            .frame(width: g.size.width * anteil)
        }
      }
      .frame(height: 8)
      Text(an && db > -60 ? String(format: "%.0f dB", db) : "–")
        .font(Schrift.zahl).foregroundStyle(Theme.textDim).frame(width: 48, alignment: .trailing)
    }
  }
}
