import ApiPackage
import SwiftUI

/// Fenster „TX Band Settings“ wie bei SmartSDR: je Band Sendeleistung, Tune-Leistung,
/// Sperre und die Sende-Ausgänge (RCA/ACC) für Endstufe & Co.
/// Jede Änderung geht sofort ans Radio (Befehle „transmit bandset“ / „interlock bandset“).
struct TxBandFenster: View {
  @State private var radio = RadioVerbindung.shared

  /// Reihenfolge wie bei SmartSDR: 160 … 6, dann der Rest (GEN, 2200, 630 …)
  private var baender: [BandSetting] {
    let reihe = ["160", "80", "60", "40", "30", "20", "17", "15", "12", "10", "6", "GEN", "2200", "630"]
    return radio.api.bandSettings.sorted {
      (reihe.firstIndex(of: $0.name) ?? 99, $0.id) < (reihe.firstIndex(of: $1.name) ?? 99, $1.id)
    }
  }

  var body: some View {
    Group {
      if radio.istVerbunden && !radio.api.bandSettings.isEmpty {
        Table(baender) {
          TableColumn("Band") { b in Text(b.name).font(Schrift.normal) }
            .width(min: 44, ideal: 50)
          TableColumn("RF Power (%)") { b in
            ProzentFeld(wert: b.rfPower) { senden(b, .rfPower, "\($0)") }
          }
          .width(min: 80, ideal: 90)
          TableColumn("Tune Power (%)") { b in
            ProzentFeld(wert: b.tunePower) { senden(b, .tunePower, "\($0)") }
          }
          .width(min: 80, ideal: 95)
          // Table nimmt höchstens 10 Spalten direkt – die Haken-Spalten daher gruppiert
          Group {
          TableColumn("PTT inhibit") { b in haken(b, \.inhibit, .inhibit) }.width(min: 60, ideal: 70)
          TableColumn("ACC TX") { b in haken(b, \.accTxEnabled, .accTxEnabled) }.width(min: 50, ideal: 60)
          TableColumn("RCA TX Req") { b in haken(b, \.rcaTxReqEnabled, .rcaTxReqEnabled) }.width(min: 60, ideal: 75)
          TableColumn("ACC TX Req") { b in haken(b, \.accTxReqEnabled, .accTxReqEnabled) }.width(min: 60, ideal: 75)
          TableColumn("RCA TX1") { b in haken(b, \.tx1Enabled, .tx1Enabled) }.width(min: 50, ideal: 60)
          TableColumn("RCA TX2") { b in haken(b, \.tx2Enabled, .tx2Enabled) }.width(min: 50, ideal: 60)
          TableColumn("RCA TX3") { b in haken(b, \.tx3Enabled, .tx3Enabled) }.width(min: 50, ideal: 60)
          TableColumn("HW ALC") { b in haken(b, \.hwAlcEnabled, .hwAlcEnabled) }.width(min: 50, ideal: 60)
          }
        }
        .tableStyle(.inset(alternatesRowBackgrounds: true))
        .scrollContentBackground(.hidden)
      } else {
        VStack {
          Spacer()
          Text(radio.istVerbunden ? "Radio hat noch keine Band-Einstellungen gemeldet" : "Radio nicht verbunden")
            .font(Schrift.normal).foregroundStyle(Theme.textDim)
          Spacer()
        }
        .frame(maxWidth: .infinity)
      }
    }
    .frame(minWidth: 820, minHeight: 420)
    .background(Theme.window)
  }

  /// Häkchen mittig in der Spalte
  private func haken(_ b: BandSetting, _ pfad: KeyPath<BandSetting, Bool>, _ eigenschaft: BandSetting.Property) -> some View {
    Toggle("", isOn: Binding(
      get: { b[keyPath: pfad] },
      set: { senden(b, eigenschaft, $0 ? "1" : "0") }
    ))
    .toggleStyle(.checkbox)
    .labelsHidden()
    .frame(maxWidth: .infinity)
  }

  private func senden(_ b: BandSetting, _ eigenschaft: BandSetting.Property, _ wert: String) {
    radio.sende(BandSetting.set(id: b.id, property: eigenschaft, value: wert))
  }
}

/// Zahl 0…100 zum Eintippen (Enter oder Verlassen des Felds übernimmt), rechtsbündig
private struct ProzentFeld: View {
  let wert: Int
  let setzen: (Int) -> Void
  @State private var text = ""
  @FocusState private var fokus: Bool

  var body: some View {
    TextField("", text: $text)
      .multilineTextAlignment(.trailing)
      .font(Schrift.zahl)
      .textFieldStyle(.plain)
      .focused($fokus)
      .onAppear { text = "\(wert)" }
      .onChange(of: wert) { _, neu in if !fokus { text = "\(neu)" } }
      .onSubmit(uebernehmen)
      .onChange(of: fokus) { _, jetzt in if !jetzt { uebernehmen() } }
  }

  private func uebernehmen() {
    guard let n = Int(text.trimmingCharacters(in: .whitespaces)) else { text = "\(wert)"; return }
    let begrenzt = min(100, max(0, n))
    text = "\(begrenzt)"
    if begrenzt != wert { setzen(begrenzt) }
  }
}
