import AppKit
import Observation
import SwiftUI
import UniformTypeIdentifiers

/// Eigenes Hintergrundbild im Spektrum (Panadapter) – Einstellung unter „Disp“.
/// Das Bild wird nach ~/Library/Application Support/xSDR64/ kopiert, damit es auch bleibt,
/// wenn das Original verschoben oder gelöscht wird.
@MainActor
@Observable
final class Hintergrundbild {
  static let shared = Hintergrundbild()

  private(set) var bild: NSImage?
  /// Abdunkeln 0…100: schwarzer Filter über dem Bild (0 = Bild unverändert, 100 = ganz schwarz)
  var abdunkeln: Double {
    didSet { UserDefaults.standard.set(abdunkeln, forKey: "hintergrundAbdunkeln") }
  }

  private var ordner: URL {
    let basis = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
    return basis.appending(path: "xSDR64")
  }
  private var datei: URL { ordner.appending(path: "Hintergrundbild") }

  private init() {
    abdunkeln = UserDefaults.standard.object(forKey: "hintergrundAbdunkeln") as? Double ?? 50
    bild = NSImage(contentsOf: datei)
  }

  /// Finder-Fenster öffnen und ein Bild wählen.
  /// Bewusst NICHT runModal: das hält die Haupt-Schleife an, Timer (Ping ans Radio) laufen nicht –
  /// im Betrieb hat das Radio die Verbindung dabei getrennt.
  func laden() {
    let panel = NSOpenPanel()
    panel.title = "Hintergrundbild wählen"
    panel.allowedContentTypes = [.image]
    panel.allowsMultipleSelection = false
    panel.canChooseDirectories = false
    panel.begin { antwort in
      MainActor.assumeIsolated {
        guard antwort == .OK, let quelle = panel.url else { return }
        Hintergrundbild.shared.uebernehmen(quelle)
      }
    }
  }

  private func uebernehmen(_ quelle: URL) {
    guard let neu = NSImage(contentsOf: quelle) else { return }
    do {
      try FileManager.default.createDirectory(at: ordner, withIntermediateDirectories: true)
      if FileManager.default.fileExists(atPath: datei.path()) { try FileManager.default.removeItem(at: datei) }
      try FileManager.default.copyItem(at: quelle, to: datei)
    } catch {
      Diagnose.log("Hintergrundbild: Kopieren fehlgeschlagen – \(error.localizedDescription)")
    }
    bild = neu
  }

  func entfernen() {
    try? FileManager.default.removeItem(at: datei)
    bild = nil
  }
}

/// Spektrum-Hintergrund: Grundfarbe, darüber das eigene Bild (falls gewählt)
struct SpektrumHintergrund: View {
  @State private var hg = Hintergrundbild.shared
  var body: some View {
    // Bild als Overlay: so bestimmt die Grundfarbe die Größe, das Bild (scaledToFill) drückt die
    // Fläche nicht breiter (wichtig bei mehreren Panadaptern nebeneinander)
    Theme.panadapter
      .overlay {
        if let bild = hg.bild {
          Image(nsImage: bild)
            .resizable()
            .scaledToFill()
          Color.black.opacity(hg.abdunkeln / 100)   // Filter: Bild dunkler machen
        }
      }
      .clipped()
    .allowsHitTesting(false)
  }
}

// MARK: - Filterfläche (Durchlassbereich des Slice)

/// Einstellungen der hellen Filterfläche im Spektrum/Wasserfall (Disp → FILTERFLÄCHE)
enum Filterflaeche {
  /// Stärke 0…40 (% Deckkraft), Standard 10
  static let staerkeKey = "filterflaecheStaerke"
  /// Farbe als Hex „RRGGBB“, Standard Weiß
  static let farbeKey = "filterflaecheFarbe"

  static func farbe(_ hex: String) -> Color {
    let wert = UInt32(hex, radix: 16) ?? 0xFFFFFF
    return Color(red: Double((wert >> 16) & 0xFF) / 255, green: Double((wert >> 8) & 0xFF) / 255,
                 blue: Double(wert & 0xFF) / 255)
  }

  static func hex(_ farbe: Color) -> String {
    guard let c = NSColor(farbe).usingColorSpace(.sRGB) else { return "FFFFFF" }
    return String(format: "%02X%02X%02X", Int(c.redComponent * 255), Int(c.greenComponent * 255), Int(c.blueComponent * 255))
  }
}
