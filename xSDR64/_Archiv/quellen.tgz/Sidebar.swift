//
//  Sidebar.swift
//  xSDR64
//
//  Created by Mathias Davidheimann on 24.09.26.
//

import SwiftUI

/// Die Blöcke der Seitenleiste – in dieser Reihenfolge erscheinen sie auch
enum SidebarBlock: String, CaseIterable, Identifiable {
  case tx = "TX"
  case mic = "MIC"
  case phone = "PHNE"
  case rx = "RX"
  case xtune = "xTUNE"      // eigener Koppler über xTune64 (nicht der Flex-Tuner)

  var id: String { rawValue }

  /// Schon auf den RimuSDR-Stil umgestellt? (Design-Vorgabe – Block für Block)
  var isRimu: Bool { true }  // alle Blöcke umgestellt (01.10.2026)

  /// Überschrift in der Kopfzeile des Blocks (Tab-Knopf nutzt die Kurzform oben)
  var title: String {
    switch self {
    case .tx: "TX"
    case .mic: "MIC"
    case .phone: "PHONE"
    case .rx: "RX"
    case .xtune: "KOPPLER · xTune64"
    }
  }
}

// MARK: - Die Seitenleiste
struct Sidebar: View {
  /// Reihenfolge und ausgeblendete Blöcke – bleiben nach dem Neustart erhalten
  @AppStorage("sidebar.order") private var orderRaw = ""
  @AppStorage("sidebar.hidden") private var hiddenRaw = ""
  /// Über welchem Block wird gerade ein anderer Block gezogen?
  @State private var dropTarget: SidebarBlock?

  /// Gespeicherte Reihenfolge; neue Blöcke kommen automatisch hinten dran
  private var order: [SidebarBlock] {
    let saved = orderRaw.split(separator: ",").compactMap { SidebarBlock(rawValue: String($0)) }
    return saved + SidebarBlock.allCases.filter { !saved.contains($0) }
  }
  private var hidden: Set<SidebarBlock> {
    Set(hiddenRaw.split(separator: ",").compactMap { SidebarBlock(rawValue: String($0)) })
  }

  var body: some View {
    VStack(spacing: Abstand.s) {
      // Tab-Knöpfe oben: blau = Block sichtbar
      HStack(spacing: Abstand.xs) {
        ForEach(SidebarBlock.allCases) { block in
          TabButton(title: block.rawValue, isOn: !hidden.contains(block)) {
            toggle(block)
          }
        }
      }
      // Die Blöcke untereinander, scrollbar falls das Fenster zu niedrig ist
      ScrollView {
        VStack(spacing: Abstand.s) {
          ForEach(order) { block in
            if !hidden.contains(block) {
              SectionBox(title: block.title, dragID: block.rawValue,
                         highlighted: dropTarget == block, rimu: block.isRimu) {
                blockContent(block)
              }
              // Ein anderer Block wird hier fallen gelassen → verschieben
              .dropDestination(for: String.self) { items, _ in
                guard let item = items.first else { return false }
                return move(item, onto: block)
              } isTargeted: { over in
                if over { dropTarget = block } else if dropTarget == block { dropTarget = nil }
              }
            }
          }
        }
      }
    }
    .frame(width: 292)
    .animation(.easeInOut(duration: 0.2), value: hiddenRaw)
    .animation(.easeInOut(duration: 0.2), value: orderRaw)
  }
  /// Welcher Inhalt gehört in welchen Block?
  @ViewBuilder
  private func blockContent(_ block: SidebarBlock) -> some View {
    switch block {
    case .tx:
      TXBlock()
    case .mic:
      MICBlock()
    case .phone:
      PHONEBlock()
    case .rx:
      RXBlock()
    case .xtune:
      XTUNEBlock()
    }
  }
  /// Block ein- bzw. ausblenden
  private func toggle(_ block: SidebarBlock) {
    var h = hidden
    if h.contains(block) { h.remove(block) } else { h.insert(block) }
    hiddenRaw = h.map(\.rawValue).sorted().joined(separator: ",")
  }
  /// Gezogenen Block an die Stelle des Ziel-Blocks setzen.
  /// Nach unten gezogen → landet unter dem Ziel, nach oben gezogen → darüber.
  private func move(_ dragged: String, onto target: SidebarBlock) -> Bool {
    guard let block = SidebarBlock(rawValue: dragged), block != target else { return false }
    var list = order
    guard let from = list.firstIndex(of: block), let to = list.firstIndex(of: target) else { return false }
    list.remove(at: from)
    guard let t = list.firstIndex(of: target) else { return false }
    list.insert(block, at: from < to ? t + 1 : t)
    orderRaw = list.map(\.rawValue).joined(separator: ",")
    dropTarget = nil
    return true
  }
}

// MARK: - Tab-Knopf oben (TX, MIC, PHNE, RX, xTUNE)
struct TabButton: View {
  let title: String
  let isOn: Bool
  let action: () -> Void

  var body: some View {
    // RimuSDR-Knopf: an = blau, aus = grau – füllt seinen Platz in der Reihe
    Button(action: action) {
      Text(title).frame(maxWidth: .infinity)
    }
    .buttonStyle(KnopfStil(art: isOn ? .an : .aus))
    .focusEffectDisabled()
  }
}

// MARK: - Ein Block mit Kopfzeile (≡ Titel)
/// ≡ anfassen und ziehen → Block verschieben; Klick auf den Titel → Block zuklappen
struct SectionBox<Content: View>: View {
  let title: String
  var dragID: String? = nil  // was beim Ziehen mitgegeben wird
  var highlighted = false  // ein anderer Block schwebt gerade darüber
  var rimu = false  // RimuSDR-Stil: dunkle Kopfzeile, Fläche #3A3A3A, Inhalt ohne Rand
  @ViewBuilder var content: Content  // was im Block steht
  @State private var expanded = true  // aufgeklappt?

  var body: some View {
    VStack(spacing: 0) {
      HStack(spacing: 0) {
        // Griff zum Ziehen
        Image(systemName: "line.3.horizontal")
          .frame(width: 34, height: 32)
          .contentShape(Rectangle())
          .pointerStyle(.grabIdle)
          .draggable(dragID ?? title) {
            // Vorschau, die beim Ziehen am Mauszeiger hängt
            Text(title)
              .font(.system(size: 13, weight: .bold))
              .foregroundStyle(Theme.text)
              .padding(.horizontal, 12)
              .padding(.vertical, 6)
              .background(Theme.sectionHeader)
          }
        // Titel: Klick klappt den Block zu bzw. auf
        Button {
          expanded.toggle()
        } label: {
          HStack {
            Text(title)
              .font(rimu ? Schrift.normalFett : .system(size: 13, weight: .bold))
            Spacer()
            // Hinweis: Klick klappt den Block zu (▲) bzw. auf (▼)
            Image(systemName: expanded ? "chevron.up" : "chevron.down")
              .font(Schrift.klein)
              .foregroundStyle(Theme.textDim)
          }
          .padding(.leading, 2)
          .padding(.trailing, 10)
          .frame(height: rimu ? Mass.zeilenHoehe : 32)
          .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .focusEffectDisabled()
      }
      .background(rimu ? Theme.rimuKopf : Theme.sectionHeader)

      if expanded {
        if rimu {
          // RimuSDR: kein Innenrand – der Block bestimmt seine Abstände selbst
          content
            .frame(maxWidth: .infinity, alignment: .leading)
        } else {
          Rectangle().fill(Theme.border).frame(height: 1)
          content
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
        }
      }
    }
    .background(rimu ? Theme.rimuBlock : Theme.panel)
    .overlay(
      Rectangle().stroke(highlighted ? Theme.accent : Theme.border,
                         lineWidth: highlighted ? 2 : 1)
    )
  }
}
