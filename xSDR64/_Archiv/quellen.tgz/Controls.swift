//
//  Controls.swift
//  xSDR64
//
//  Created by Mathias Davidheimann on 24.09.26.
//

import SwiftUI

// MARK: - Messskala im RimuSDR-Stil
/// Oben Beschriftung, darunter blaue Linie mit Teilstrichen, rechts roter Bereich.
/// Positionen laufen von 0 (links) bis 1 (rechts).
struct ScaleMeter: View {
  struct Mark {
    let pos: Double  // 0...1
    let text: String
    var red = false  // Beschriftung rot?
  }

  let marks: [Mark]
  let redFrom: Double  // ab hier ist die Linie rot (0...1)
  var value: Double = 0  // Messwert 0...1
  var ticks = 10  // in wie viele Abschnitte die Skala geteilt ist

  var body: some View {
    GeometryReader { geo in
      let w = geo.size.width
      ZStack(alignment: .topLeading) {
        // Beschriftung
        ForEach(marks.indices, id: \.self) { i in
          Text(marks[i].text)
            .font(Schrift.klein)
            .foregroundStyle(marks[i].red ? Theme.meterRed : Theme.text)
            .fixedSize()
            .position(x: min(max(marks[i].pos * w, 10), w - 10), y: 7)
        }
        // grüner Messwert-Balken
        Rectangle()
          .fill(Theme.meterValue)
          .frame(width: w * min(max(value, 0), 1), height: 6)
          .offset(y: 21)
        // Spitzenwert: bleibt 1 s stehen
        SpitzenStrich(value: value, hoehe: 12, y: 24)
        // Skalenlinie: blau bis redFrom, danach rot
        Path { p in
          p.move(to: CGPoint(x: 0, y: 24))
          p.addLine(to: CGPoint(x: w * redFrom, y: 24))
        }
        .stroke(Theme.meterBlue, lineWidth: 2)
        Path { p in
          p.move(to: CGPoint(x: w * redFrom, y: 24))
          p.addLine(to: CGPoint(x: w, y: 24))
        }
        .stroke(Theme.meterRed, lineWidth: 2)
        // Teilstriche: jeder zweite lang
        Path { p in
          for i in 0...ticks {
            let x = min(max(Double(i) / Double(ticks) * w, 1), w - 1)
            let long = i % 2 == 0
            p.move(to: CGPoint(x: x, y: long ? 19 : 21))
            p.addLine(to: CGPoint(x: x, y: long ? 29 : 27))
          }
        }
        .stroke(Theme.meterBlue, lineWidth: 1.5)
      }
    }
    .frame(height: 32)
  }
}

// MARK: - Flacher Knopf (blau = eingeschaltet, Farbe wählbar)
struct FlatButton: View {
  let title: String
  var isOn = false
  var onColor = Theme.accent  // Farbe, wenn eingeschaltet (blau, rot = TX, grün)
  var onBorder = Theme.tabOnBorder  // (bleibt, damit alte Aufrufe passen)
  let action: () -> Void

  /// 01.10.2026: zeichnet jetzt im RimuSDR-Knopfstil (KnopfStil aus Stil.swift)
  private var art: KnopfArt {
    guard isOn else { return .aus }
    if onColor == Theme.txOn { return .rot }
    if onColor == Theme.meterValue { return .gruen }
    return .an
  }

  var body: some View {
    Button(action: action) {
      Text(title).frame(maxWidth: .infinity)
    }
    .buttonStyle(KnopfStil(art: art))
    .focusEffectDisabled()
  }
}

// MARK: - Aufklappmenü im Look des FlatButton (gleiche Höhe, gleicher Rahmen)
struct FlatPicker<Value: Hashable>: View {
  @Binding var selection: Value
  let options: [Value]
  let title: (Value) -> String  // wie ein Eintrag beschriftet wird

  /// 01.10.2026: zeichnet jetzt wie RimuPicker (Knopf „aus“ mit kleinem ▾)
  var body: some View {
    RimuPicker(selection: $selection, options: options, title: title)
  }
}
