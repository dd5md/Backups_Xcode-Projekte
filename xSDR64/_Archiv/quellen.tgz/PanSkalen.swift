import AppKit
import ApiPackage
import SwiftUI

/// Hilfen für Raster und Beschriftung von Spektrum und Wasserfall
enum PanSkala {
  /// Sichtbarer Bereich (links, Breite) in Hz – ohne Radio ein Platzhalter
  static func bereich(_ pan: Panadapter?) -> (links: Double, breite: Double) {
    guard let pan, pan.bandwidth > 0 else { return (14_100_000, 200_000) }
    return (Double(pan.center) - Double(pan.bandwidth) / 2, Double(pan.bandwidth))
  }

  /// Abstand der Frequenzmarken: so, dass etwa alle 90–150 Punkte eine Marke steht
  static func frequenzSchritt(breiteHz: Double, breitePunkte: CGFloat) -> Double {
    let schritte: [Double] = [500, 1_000, 2_000, 2_500, 5_000, 10_000, 20_000, 25_000,
                              50_000, 100_000, 200_000, 250_000, 500_000, 1_000_000]
    let gewuenscht = breiteHz / Double(max(1, breitePunkte / 110))
    return schritte.first { $0 >= gewuenscht } ?? 1_000_000
  }

  /// Marken (Frequenz in Hz) im sichtbaren Bereich
  static func frequenzMarken(_ pan: Panadapter?, breite: CGFloat) -> [Double] {
    let b = bereich(pan)
    let schritt = frequenzSchritt(breiteHz: b.breite, breitePunkte: breite)
    var f = (b.links / schritt).rounded(.up) * schritt
    var marken = [Double]()
    while f <= b.links + b.breite {
      marken.append(f)
      f += schritt
    }
    return marken
  }

  static func x(_ hz: Double, _ pan: Panadapter?, breite: CGFloat) -> CGFloat {
    let b = bereich(pan)
    return CGFloat((hz - b.links) / b.breite) * breite
  }

  /// 14125000 → "14.125", bei feinen Schritten mit mehr Stellen
  static func text(_ hz: Double, schritt: Double) -> String {
    String(format: schritt < 1_000 ? "%.4f" : "%.3f", hz / 1_000_000)
  }

  /// dBm-Bereich des Panadapters (oben, unten)
  static func dbm(_ pan: Panadapter?) -> (oben: CGFloat, unten: CGFloat) {
    guard let pan, pan.maxDbm > pan.minDbm else { return (-40, -135) }
    return (pan.maxDbm, pan.minDbm)
  }
}

/// Raster im Spektrum: senkrecht an den Frequenzmarken, waagerecht alle 10 dB, rechts die dBm-Werte
struct SpektrumRaster: View {
  let pan: Panadapter?

  var body: some View {
    Canvas { ctx, size in
      let linie = Color.white.opacity(0.10)
      // senkrecht
      for f in PanSkala.frequenzMarken(pan, breite: size.width) {
        let x = PanSkala.x(f, pan, breite: size.width)
        ctx.stroke(Path { $0.move(to: CGPoint(x: x, y: 0)); $0.addLine(to: CGPoint(x: x, y: size.height)) },
                   with: .color(linie), lineWidth: 1)
      }
      // waagerecht + Beschriftung
      let d = PanSkala.dbm(pan)
      let spanne = d.oben - d.unten
      var wert = (d.oben / 10).rounded(.down) * 10
      while wert > d.unten {
        let y = (d.oben - wert) / spanne * size.height
        ctx.stroke(Path { $0.move(to: CGPoint(x: 0, y: y)); $0.addLine(to: CGPoint(x: size.width, y: y)) },
                   with: .color(linie), lineWidth: 1)
        ctx.draw(Text("\(Int(wert))").font(Schrift.klein).foregroundStyle(Theme.textDim),
                 at: CGPoint(x: size.width - 6, y: y), anchor: .trailing)
        wert -= 10
      }
    }
    .allowsHitTesting(false)
  }
}

/// Frequenzleiste zwischen Spektrum und Wasserfall.
/// Mit der Maus nach oben/unten ziehen verschiebt die Grenze (Höhe des Wasserfalls),
/// nach rechts/links ziehen zoomt (rechts = enger/mehr Details, links = breiter).
struct FrequenzLeiste: View {
  let pan: Panadapter?
  /// Anteil des Spektrums an der Gesamthöhe
  @Binding var anteil: Double
  let gesamtHoehe: CGFloat

  static let hoehe: CGFloat = 22
  @State private var startAnteil: Double?
  @State private var startBreite: Int?
  /// Richtung wird beim ersten Ziehen festgelegt: true = Zoom, false = Höhe
  @State private var zoomRichtung: Bool?

  var body: some View {
    Canvas { ctx, size in
      let marken = PanSkala.frequenzMarken(pan, breite: size.width)
      let schritt = marken.count > 1 ? marken[1] - marken[0] : 10_000
      for f in marken {
        let x = PanSkala.x(f, pan, breite: size.width)
        ctx.stroke(Path { $0.move(to: CGPoint(x: x, y: 0)); $0.addLine(to: CGPoint(x: x, y: 4)) },
                   with: .color(Theme.textDim), lineWidth: 1)
        ctx.draw(Text(PanSkala.text(f, schritt: schritt)).font(Schrift.klein.monospacedDigit())
                   .foregroundStyle(Theme.text),
                 at: CGPoint(x: x, y: size.height / 2 + 1), anchor: .center)
      }
    }
    .frame(height: Self.hoehe)
    .background(Theme.rimuPanKopf)
    .overlay(alignment: .top) { Rectangle().fill(Theme.border).frame(height: 1) }
    .overlay(alignment: .bottom) { Rectangle().fill(Theme.border).frame(height: 1) }
    .contentShape(Rectangle())
    .onHover { drin in
      if drin { NSCursor.openHand.push() } else { NSCursor.pop() }
    }
    .gesture(
      DragGesture(minimumDistance: 3)
        .onChanged { g in
          if zoomRichtung == nil {
            zoomRichtung = abs(g.translation.width) > abs(g.translation.height)
          }
          if zoomRichtung == true {
            guard let pan else { return }
            let start = startBreite ?? pan.bandwidth
            startBreite = start
            RadioVerbindung.shared.panBreite(pan, Double(start) * exp(-Double(g.translation.width) / 250), sofort: false)
          } else {
            let start = startAnteil ?? anteil
            startAnteil = start
            guard gesamtHoehe > 0 else { return }
            anteil = min(0.85, max(0.15, start + Double(g.translation.height / gesamtHoehe)))
          }
        }
        .onEnded { _ in
          if zoomRichtung == true, let pan {
            RadioVerbindung.shared.panBreite(pan, Double(pan.bandwidth), sofort: true)
          }
          zoomRichtung = nil
          startAnteil = nil
          startBreite = nil
        }
    )
    .help("Ziehen: links/rechts = Zoom, hoch/runter = Höhe von Spektrum und Wasserfall")
  }
}
