import ApiPackage
import Observation
import os
import SwiftUI

// MARK: - Empfang (läuft auf der UDP-Empfangs-Queue, nicht auf dem Haupt-Thread)

/// Setzt die Panadapter-Pakete des Radios zu vollständigen Bildern zusammen.
/// Ein Bild = eine Zeile Werte (je Bildpunkt in der Breite einer), verteilt auf mehrere UDP-Pakete.
nonisolated final class SpektrumEmpfang: @unchecked Sendable {
  static let shared = SpektrumEmpfang()

  /// Zwischenspeicher je Panadapter (Stream-ID)
  private struct Sammlung {
    var bins = [UInt16]()
    var bild: UInt32?
    var gesammelt = 0
  }
  private var sammlungen = [UInt32: Sammlung]()

  /// Ist schon ein Bild zum Haupt-Thread unterwegs? Dann wird das nächste verworfen
  /// (Anzeige hinkt nie hinterher, auch wenn die Oberfläche mal kurz beschäftigt ist)
  private let unterwegs = OSAllocatedUnfairLock(initialState: Set<UInt32>())

  /// Rückruf für das ApiPackage – hier gebaut, damit er nicht an den Haupt-Thread gebunden ist
  var panadapterRueckruf: @Sendable (UInt32, [UInt8]) -> Void {
    { [self] id, payload in self.panadapter(id, payload) }
  }

  /// Panadapter-Paket: 12 Byte Kopf, danach die Werte (je 2 Byte, Big Endian)
  ///   Startindex u16 | Anzahl u16 | Bytes je Wert u16 | Werte im ganzen Bild u16 | Bildnummer u32
  func panadapter(_ id: UInt32, _ p: [UInt8]) {
    guard p.count >= 12 else { return }
    func u16(_ o: Int) -> Int { Int(p[o]) << 8 | Int(p[o + 1]) }
    let start = u16(0), anzahl = u16(2), groesse = u16(4), gesamt = u16(6)
    let bild = UInt32(p[8]) << 24 | UInt32(p[9]) << 16 | UInt32(p[10]) << 8 | UInt32(p[11])
    guard gesamt > 0, groesse == 2, start + anzahl <= gesamt, p.count >= 12 + anzahl * 2 else { return }

    var s = sammlungen[id] ?? Sammlung()
    if start == 0 {
      // Anfang eines neuen Bildes
      s.bild = bild
      s.gesammelt = 0
      if s.bins.count != gesamt { s.bins = [UInt16](repeating: 0, count: gesamt) }
    }
    // fehlt ein Stück, auf den nächsten Bildanfang warten
    guard s.bild == bild, s.bins.count == gesamt else { sammlungen[id] = s; return }

    for i in 0..<anzahl {
      s.bins[start + i] = UInt16(p[12 + 2 * i]) << 8 | UInt16(p[13 + 2 * i])
    }
    s.gesammelt += anzahl

    if s.gesammelt >= gesamt {
      let fertig = s.bins
      s.bild = nil
      s.gesammelt = 0
      liefern(id, fertig)
    }
    sammlungen[id] = s
  }

  private func liefern(_ id: UInt32, _ bins: [UInt16]) {
    let frei = unterwegs.withLock { belegt -> Bool in
      belegt.insert(id).inserted
    }
    guard frei else { return }
    DispatchQueue.main.async {
      SpektrumModell.shared.bins[id] = bins
      self.unterwegs.withLock { _ = $0.remove(id) }
    }
  }
}

// MARK: - Modell für die Oberfläche

@MainActor
@Observable
final class SpektrumModell {
  static let shared = SpektrumModell()
  private init() {}

  /// Neuestes Bild je Panadapter: Werte = Höhe in Bildpunkten von oben (0 = oberer Rand = max dBm)
  var bins = [UInt32: [UInt16]]()

  /// Zuletzt ans Radio gemeldete Größe je Panadapter (das Radio rechnet die Werte darauf)
  @ObservationIgnored var groesse = [UInt32: CGSize]()
  @ObservationIgnored private var warten = [UInt32: Task<Void, Never>]()

  /// Größe der Anzeige ans Radio melden – kurz gewartet, damit beim Ziehen am Fenster
  /// nicht hunderte Befehle rausgehen
  func melde(_ pan: Panadapter, _ size: CGSize) {
    let id = pan.id
    warten[id]?.cancel()
    warten[id] = Task {
      try? await Task.sleep(for: .milliseconds(200))
      guard !Task.isCancelled, size.width > 10, size.height > 10 else { return }
      let x = Int(size.width), y = Int(size.height)
      groesse[id] = CGSize(width: x, height: y)
      RadioVerbindung.shared.sende("display pan set 0x\(String(id, radix: 16, uppercase: true)) xpixels=\(x)")
      RadioVerbindung.shared.sende("display pan set 0x\(String(id, radix: 16, uppercase: true)) ypixels=\(y)")
    }
  }
}

// MARK: - Anzeige

/// Spektrum-Linie mit Füllung. Zeichnet nur, wenn ein neues Bild vom Radio da ist.
struct SpektrumAnsicht: View {
  let pan: Panadapter?
  private let modell = SpektrumModell.shared
  @AppStorage("spektrumFuellung") private var fuellung = 1        // 0 aus, 1 an, 2 Farbe
  @AppStorage("spektrumFuellStaerke") private var fuellStaerke = 35.0

  var body: some View {
    GeometryReader { geo in
      let id = pan?.id ?? 0
      let bins = modell.bins[id] ?? []
      let hoehe = modell.groesse[id]?.height ?? geo.size.height
      Canvas { ctx, size in
        guard bins.count > 1 else { return }
        let dx = size.width / CGFloat(bins.count - 1)
        let fy = size.height / max(1, hoehe)
        var linie = Path()
        for (i, wert) in bins.enumerated() {
          let p = CGPoint(x: CGFloat(i) * dx, y: CGFloat(wert) * fy)
          if i == 0 { linie.move(to: p) } else { linie.addLine(to: p) }
        }
        if fuellung > 0 {
          var flaeche = linie
          flaeche.addLine(to: CGPoint(x: size.width, y: size.height))
          flaeche.addLine(to: CGPoint(x: 0, y: size.height))
          flaeche.closeSubpath()
          if fuellung == 2 {
            // Farbe wie SmartSDR: an der Linie (Grundrauschen) olivgrün → grün → türkis → blau unten,
            // kräftig deckend (Stärke 50 = voll)
            let a = min(1, fuellStaerke / 50)
            let rauschen = CGFloat(bins.reduce(0) { $0 + Int($1) }) / CGFloat(bins.count) * fy
            // Verlauf über die ganze Höhe: Signale ÜBER dem Rauschen bekommen dasselbe Grün wie die
            // Fläche darunter (wie SmartSDR) – vorher blieben sie im kräftigen Oliv/Gelb stehen.
            // Am Rauschen olivgrün, nach unten über Türkis zu Blau und durchsichtig.
            let n = max(0.02, min(0.95, rauschen / max(1, size.height)))   // Lage des Rauschens 0…1
            let unten = 1 - n
            ctx.fill(flaeche, with: .linearGradient(
              Gradient(stops: [
                // über dem Rauschen etwas durchsichtiger (Nutzerwunsch 05.10.: „ein bisschen durchgucken“)
                .init(color: Color(red: 0.32, green: 0.62, blue: 0.34).opacity(a * 0.68), location: 0),
                .init(color: Color(red: 0.40, green: 0.62, blue: 0.30).opacity(a * 0.78), location: n * 0.9),
                .init(color: Color(red: 0.56, green: 0.62, blue: 0.27).opacity(a), location: n),
                .init(color: Color(red: 0.30, green: 0.60, blue: 0.26).opacity(a * 0.85), location: n + unten * 0.35),
                .init(color: Color(red: 0.24, green: 0.58, blue: 0.62).opacity(a * 0.45), location: n + unten * 0.7),
                .init(color: Color(red: 0.10, green: 0.24, blue: 0.80).opacity(a * 0.10), location: 1),
              ]),
              startPoint: CGPoint(x: 0, y: 0), endPoint: CGPoint(x: 0, y: size.height)))
          } else {
            let a = fuellStaerke / 100
            ctx.fill(flaeche, with: .linearGradient(
              Gradient(colors: [Color.white.opacity(a), Color.white.opacity(a * 0.15)]),
              startPoint: CGPoint(x: 0, y: size.height * 0.4), endPoint: CGPoint(x: 0, y: size.height)))
          }
        }
        ctx.stroke(linie, with: .color(.white.opacity(0.9)), lineWidth: 1)
      }
      .onChange(of: geo.size, initial: true) { _, neu in
        if let pan { modell.melde(pan, neu) }
      }
      .onChange(of: pan?.id) { _, _ in
        if let pan { modell.melde(pan, geo.size) }
      }
    }
  }
}
