import AppKit
import SwiftUI

@main struct MyApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        WindowGroup {
            // ZoomContainer: ganzes Fenster verkleinern/vergrößern (Menü Darstellung, ⌘− / ⌘+ / ⌘0)
            ZoomContainer {
                ContentView()
                    .frame(minWidth: 1100, minHeight: 700)
            }
            .preferredColorScheme(.dark)
        }
        .defaultSize(width: 1440, height: 900)
        .commands {
            ChainUndoCommands()   // ⌘Z / ⇧⌘Z für die Audiokette
            ZoomCommands()        // Darstellung → Kleiner / Größer / Originalgröße
            ExportCommands()      // Ablage → Exportieren; Beenden und Fenster behalten
            RadioMenue()          // Menü „Radio“: Audio-Loopback …
            SliceMenue()          // Menüs „Slice“ und „Panadapter“
        }

        // Profile (Menü Radio → Profile)
        Window(ProfilArt.global.titel, id: ProfilArt.global.fensterId) {
            ProfilFenster(art: .global).preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .defaultSize(width: 460, height: 480)
        Window(ProfilArt.tx.titel, id: ProfilArt.tx.fensterId) {
            ProfilFenster(art: .tx).preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .defaultSize(width: 460, height: 480)
        Window(ProfilArt.mic.titel, id: ProfilArt.mic.fensterId) {
            ProfilFenster(art: .mic).preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .defaultSize(width: 460, height: 480)

        // App-Einstellungen: xSDR64 → Einstellungen … (⌘,)
        Settings {
            AppEinstellungen()
        }

        // Slice-Optionen (Menü Slice)
        Window("Slice-Optionen", id: "sliceoptionen") {
            SliceOptionenFenster().preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .windowResizability(.contentSize)

        // Klangaufbereitung im Radio (Menü Radio): TX/RX-EQ, PROC, DEXP
        Window("Klangaufbereitung im Radio", id: "klang") {
            KlangFenster().preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .windowResizability(.contentSize)

        // Radio-Einstellungen (Menü Radio)
        Window("Radio-Einstellungen", id: "radioeinstellungen") {
            RadioEinstellungen().preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .windowResizability(.contentSize)

        // RC-28 Drehknopf (Menü Radio)
        Window("RC-28", id: "rc28") {
            RC28Fenster().preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .windowResizability(.contentSize)

        // USB Cables (Menü Radio)
        Window("USB Cables", id: "usbkabel") {
            UsbKabelFenster().preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .defaultSize(width: 680, height: 360)

        // TX Band Settings (Menü Radio)
        Window("TX Band Settings", id: "txband") {
            TxBandFenster().preferredColorScheme(.dark).background(UeberAppFenster())
        }
        .defaultSize(width: 900, height: 520)

        // Audio-Loopback (Menü Radio)
        Window("Audio-Loopback", id: "loopback") {
            LoopbackFenster()
                .preferredColorScheme(.dark)
                .background(UeberAppFenster())   // bleibt über dem Hauptfenster, bis es geschlossen wird
        }
        .windowResizability(.contentSize)

        // Plugin-Liste als eigenes kleines Fenster (schwebt über dem Hauptfenster)
        Window("Plugins", id: "plugins") {
            PluginPanel(catalog: AudioWelt.shared.catalog) { AudioWelt.shared.host.addPlugin($0) }
                .frame(width: 330, height: 560)
                .preferredColorScheme(.dark)
                .background(UeberAppFenster())   // nur über xSDR64, nicht über anderen Programmen
        }
        .windowResizability(.contentSize)
        .defaultPosition(.leading)
    }
}

/// Beenden wie in xHost64: erst selbst sichern, dann sofort beenden (_exit).
/// Grund: manche Plugins (z. B. VUMTdeluxe/JUCE) stürzen ab, wenn macOS sie beim Beenden abräumt.
final class AppDelegate: NSObject, NSApplicationDelegate {
    /// Audio stoppen, Ketten sichern – setzt AudioHost.mitAppVerbinden()
    static var beforeQuit: (() -> Void)?
    /// „Beenden und Fenster behalten“ (aus xHost64, in xSDR64 noch ohne Menüpunkt)
    static var keepWindows = false

    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        Self.beforeQuit?()
        FensterLage.merken()        // Fensterlage sichern – _exit überspringt das sonst
        UserDefaults.standard.synchronize()
        Diagnose.log("Programm beendet (sauber, ohne Plugin-Abräumen) – Auslöser: \(Self.beendenAusloeser())")
        _exit(0)
    }

    /// Menü „Radio“ direkt hinter den App-Namen stellen (wie SmartSDR).
    /// SwiftUI legt eigene Menüs sonst erst hinter „Darstellung“ ab.
    func applicationDidFinishLaunching(_ notification: Notification) {
        DispatchQueue.main.async { Self.radioMenueNachVorne() }
        // SwiftUI baut die Menüleiste ab und zu neu (z. B. wenn ein Fenster aufgeht) –
        // danach „Radio“ wieder nach vorne holen. Die Prüfung kostet praktisch nichts.
        NotificationCenter.default.addObserver(forName: NSApplication.didUpdateNotification, object: nil, queue: .main) { _ in
            MainActor.assumeIsolated { Self.radioMenueNachVorne() }
        }
    }

    func applicationDidBecomeActive(_ notification: Notification) {
        Self.radioMenueNachVorne()
    }

    static func radioMenueNachVorne() {
        guard let leiste = NSApp.mainMenu else { return }
        verschiebe("Radio", nach: 1, in: leiste)
        // wie SmartSDR: Slice und Panadapter direkt hinter „Bearbeiten“/„Edit“
        if let edit = leiste.items.firstIndex(where: { $0.title == "Edit" || $0.title == "Bearbeiten" }) {
            verschiebe("Slice", nach: edit + 1, in: leiste)
            if let slice = leiste.items.firstIndex(where: { $0.title == "Slice" }) {
                verschiebe("Panadapter", nach: slice + 1, in: leiste)
            }
        }
    }

    private static func verschiebe(_ titel: String, nach ziel: Int, in leiste: NSMenu) {
        guard let i = leiste.items.firstIndex(where: { $0.title == titel }), i != ziel,
              ziel <= leiste.items.count else { return }
        let eintrag = leiste.items[i]
        leiste.removeItem(at: i)
        leiste.insertItem(eintrag, at: min(i < ziel ? ziel - 1 : ziel, leiste.items.count))
    }

    /// Letztes Fenster zu → App beenden (sonst hielte sie das Audio-Gerät fest)
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        Self.letztesFensterZu = true
        return true
    }

    /// für das Diagnose-Protokoll: wodurch wurde beendet?
    private static var letztesFensterZu = false
    private static func beendenAusloeser() -> String {
        if letztesFensterZu { return "letztes Fenster geschlossen" }
        if let ae = NSAppleEventManager.shared().currentAppleEvent {
            // „spid“ = Prozess-ID des Absenders (z. B. ein Installer/Updater, der Programme beendet)
            let pid = ae.attributeDescriptor(forKeyword: AEKeyword(0x7370_6964))?.int32Value ?? 0
            let name = NSRunningApplication(processIdentifier: pid)?.localizedName ?? "?"
            return "Beenden-Befehl von außen (PID \(pid), \(name))"
        }
        if let e = NSApp.currentEvent, e.type == .keyDown {
            return "Tastatur (\(e.modifierFlags.contains(.command) ? "⌘" : "")\(e.charactersIgnoringModifiers ?? ""))"
        }
        if let e = NSApp.currentEvent { return "Ereignis Typ \(e.type.rawValue) (z. B. Menü „Beenden“)" }
        return "unbekannt"
    }
}
