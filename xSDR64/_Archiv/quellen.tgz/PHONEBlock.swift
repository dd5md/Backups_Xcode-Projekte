import ApiPackage
import SwiftUI

/// Inhalt des PHONE-Blocks: VOX + Pegel, Delay, TX-Filter Low/High Cut
/// (ohne AM Carrier; DEXP am 05.10. ergänzt – Flex schaltet ihn gern wieder ein und er nimmt den „Punch“)
/// 01.10.2026: auf RimuSDR-Stil umgestellt (Design-Vorgabe)
struct PHONEBlock: View {
  // Ersatzwerte, solange kein Radio verbunden ist – verbunden kommen alle Werte vom Radio
  @State private var voxOn = false
  @State private var voxLevel = 50.0
  @State private var voxDelay = 25.0
  @State private var lowCut = 100  // Hz
  @State private var highCut = 2900  // Hz
  @State private var dexpOn = false
  @State private var dexpLevel = 0.0

  private let radio = RadioVerbindung.shared

  var body: some View {
    let vox = radio.txSchalter($voxOn, \.voxEnabled) { "transmit set vox_enable=\($0 ? 1 : 0)" }
    let low = radio.txZahl($lowCut, \.txFilterLow, "transmit set filter_low")
    let high = radio.txZahl($highCut, \.txFilterHigh, "transmit set filter_high")
    VStack(spacing: 0) {
      // VOX: Knopf + Pegel
      ElementReglerZeile(value: radio.txRegler($voxLevel, \.voxLevel, "transmit set vox_level")) {
        Button("VOX") { vox.wrappedValue.toggle() }
          .buttonStyle(KnopfStil(art: vox.wrappedValue ? .an : .aus, breite: 78))
      }
      // Haltezeit der VOX
      ReglerZeile(label: "Delay:", value: radio.txRegler($voxDelay, \.voxDelay, "transmit set vox_delay"))

      // DEXP (Expander im Radio): Knopf + Stufe – rot markiert, wenn an (verändert die Dynamik deutlich)
      let dexp = radio.txSchalter($dexpOn, \.companderEnabled) { "transmit set compander=\($0 ? 1 : 0)" }
      ElementReglerZeile(value: radio.txRegler($dexpLevel, \.companderLevel, "transmit set compander_level")) {
        Button("DEXP") { dexp.wrappedValue.toggle() }
          .buttonStyle(KnopfStil(art: dexp.wrappedValue ? .rot : .aus, breite: 78))
          .help("Expander im Radio – macht leise Stellen leiser. Für die Audiokette normalerweise AUS.")
      }

      // TX-Filter: Überschriften über den Feldern, wie in RimuSDR
      HStack(spacing: Abstand.s) {
        Spacer().frame(width: 78)
        Text("Low Cut").frame(maxWidth: .infinity)
        Text("High Cut").frame(maxWidth: .infinity)
      }
      .font(Schrift.normal)
      .padding(.top, Abstand.xs)
      HStack(spacing: Abstand.s) {
        Text("TX Filter:")
          .frame(width: 78, alignment: .leading)
        // untere Grenze darf die obere nicht überholen (mind. 100 Hz Abstand)
        HzEingabe(value: low, range: 0...max(0, high.wrappedValue - 100), breite: nil)
        HzEingabe(value: high, range: min(low.wrappedValue + 100, 10000)...10000, breite: nil)
      }
      .font(Schrift.normal)
      .frame(height: Mass.zeilenHoehe)
    }
    .padding(Abstand.s)
    .foregroundStyle(Theme.text)
  }
}
