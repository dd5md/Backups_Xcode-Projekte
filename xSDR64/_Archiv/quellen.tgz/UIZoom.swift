//
//  UIZoom.swift
//  xSDR64 – aus xHost64 übernommen (29.09.2026)
//
//  Zoom für das ganze Fenster – wie ⌘+ / ⌘− im Browser:
//  Menü Darstellung → Kleiner (⌘−), Größer (⌘+), Originalgröße (⌘0).
//  Alles im Fenster wird gemeinsam verkleinert: Schrift, Knöpfe, Zeilen, Abstände.
//  Der gewählte Wert wird gemerkt (UserDefaults „uiZoom“).
//
//  Wie es funktioniert: Der Inhalt wird so angeordnet, als wäre das Fenster größer
//  (Fenstergröße ÷ Zoom), und dann als Ganzes verkleinert gezeichnet. Die Mindestgröße
//  des Fensters rechnet mit – so passt weiterhin alles hinein.
//

import SwiftUI

enum UIZoom {
    static let key = "uiZoom"
    static let steps: [Double] = [0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1.0, 1.1, 1.2]
    static let standard = 1.0          // xSDR64: Vorgabe 100 %

    /// Aktueller Zoom (auch für Code außerhalb der Oberfläche, z.B. Fenster vergrößern)
    static var current: Double {
        let value = UserDefaults.standard.double(forKey: key)
        return value > 0 ? value : standard
    }

    static func smaller(_ value: Double) -> Double {
        steps.last { $0 < value - 0.001 } ?? value
    }

    static func larger(_ value: Double) -> Double {
        steps.first { $0 > value + 0.001 } ?? value
    }
}

/// Ordnet den Inhalt „größer“ an und zeichnet ihn verkleinert
struct ZoomedLayout: Layout {
    let scale: CGFloat

    private func inner(_ proposal: ProposedViewSize) -> ProposedViewSize {
        ProposedViewSize(width: proposal.width.map { $0 / scale },
                         height: proposal.height.map { $0 / scale })
    }

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let child = subviews.first else { return .zero }
        let size = child.sizeThatFits(inner(proposal))
        return CGSize(width: size.width * scale, height: size.height * scale)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        guard let child = subviews.first else { return }
        child.place(at: bounds.origin, anchor: .topLeading,
                    proposal: ProposedViewSize(width: bounds.width / scale, height: bounds.height / scale))
    }
}

/// Hülle um das Fenster-Innere
struct ZoomContainer<Content: View>: View {
    @AppStorage(UIZoom.key) private var zoom = UIZoom.standard
    @ViewBuilder let content: Content

    var body: some View {
        ZoomedLayout(scale: zoom) {
            content
                .scaleEffect(zoom, anchor: .topLeading)
        }
        .animation(.easeInOut(duration: 0.2), value: zoom)
    }
}

/// Menü „Darstellung“: Kleiner / Größer / Originalgröße
struct ZoomCommands: Commands {
    @AppStorage(UIZoom.key) private var zoom = UIZoom.standard

    var body: some Commands {
        CommandGroup(before: .toolbar) {
            Button("Kleiner") { zoom = UIZoom.smaller(zoom) }
                .keyboardShortcut("-", modifiers: .command)
            Button("Größer") { zoom = UIZoom.larger(zoom) }
                .keyboardShortcut("+", modifiers: .command)
            Button("Originalgröße (100 %)") { zoom = 1.0 }
                .keyboardShortcut("0", modifiers: .command)
            Text("Zoom jetzt: \(Int((zoom * 100).rounded())) %")
            Divider()
        }
    }
}
