import ApiPackage
import Observation
import SwiftUI

/// Audiokette je Mikrofon-Profil: Wird im Radio ein Mic-Profil geladen
/// (Profil-Fenster, MIC-Block oder über ein Global-Profil), schaltet xSDR64 die zugeordnete Kette ein.
/// Ohne Zuordnung bleibt die aktuelle Kette stehen.
/// Gemerkt wird der Name der Kette (die Ketten haben keine dauerhafte ID).
@MainActor
@Observable
final class KettenZuordnung {
  static let shared = KettenZuordnung()

  private let schluessel = "kettenJeMicProfil"
  /// Mic-Profil → Name der Audiokette
  private(set) var zuordnung: [String: String]
  private var letztesProfil: String?

  private init() {
    zuordnung = UserDefaults.standard.dictionary(forKey: "kettenJeMicProfil") as? [String: String] ?? [:]
  }

  private var host: AudioHost { AudioWelt.shared.host }

  /// Namen aller Ketten (für die Auswahl)
  var kettenNamen: [String] { host.chains.map(\.name) }

  func kette(fuer profil: String) -> String? { zuordnung[profil] }

  /// Zuordnung setzen (nil = keine). Ist das Profil gerade aktiv, gleich umschalten.
  func setze(_ kette: String?, fuer profil: String) {
    zuordnung[profil] = kette
    UserDefaults.standard.set(zuordnung, forKey: schluessel)
    if profil == RadioVerbindung.shared.profil("mic")?.current { umschalten(profil) }
  }

  /// Beim Start einmal aufrufen: beobachtet das aktuelle Mic-Profil des Radios
  func beobachten() {
    withObservationTracking {
      _ = RadioVerbindung.shared.profil("mic")?.current
    } onChange: {
      Task { @MainActor in
        KettenZuordnung.shared.pruefen()
        KettenZuordnung.shared.beobachten()
      }
    }
    pruefen()
  }

  private func pruefen() {
    guard let jetzt = RadioVerbindung.shared.profil("mic")?.current, !jetzt.isEmpty else {
      letztesProfil = nil
      return
    }
    guard jetzt != letztesProfil else { return }
    letztesProfil = jetzt
    umschalten(jetzt)
  }

  private func umschalten(_ profil: String) {
    guard let name = zuordnung[profil],
          let kette = host.chains.first(where: { $0.name == name }),
          kette.id != host.activeChainID else { return }
    Diagnose.log("Mic-Profil „\(profil)“ → Audiokette „\(name)“")
    host.switchChain(to: kette.id)
  }
}
