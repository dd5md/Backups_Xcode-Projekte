import SwiftUI

/// Alle Farben des xSDR64-Designs an einer Stelle.
enum Theme {
    static let window        = Color(hex: 0x1E1E1E)  // Fensterhintergrund
    static let bar           = Color(hex: 0x2D2D2D)  // obere Leiste
    static let statusBar     = Color(hex: 0x1E1E1E)  // untere Leiste
    static let panel         = Color(hex: 0x272727)  // Blöcke der Seitenleiste
    static let sectionHeader = Color(hex: 0x1A1A1A)  // Kopfzeile eines Blocks
    static let border        = Color(hex: 0x434343)  // Rahmenlinien
    static let panadapter    = Color(hex: 0x164B69)  // Spektrum-Hintergrund
    static let waterfall     = Color(hex: 0x0A1EC8)  // Wasserfall-Hintergrund
    static let text          = Color(hex: 0xE2E4E7)  // normale Schrift
    static let textDim       = Color(hex: 0xB9BEC4)  // gedämpfte Schrift
    static let accent        = Color(hex: 0x396EB0)  // aktive (blaue) Knöpfe
    static let control       = Color(hex: 0x414145)  // Knopf-Hintergrund
    static let controlBorder = Color(hex: 0x151515)  // Knopf-Rahmen
    static let tabOn         = Color(hex: 0x396EB0)  // Tab-Knopf eingeschaltet
    static let tabOnBorder   = Color(hex: 0x4A9FF5)  // Rahmen Tab-Knopf eingeschaltet
    static let meterBlue     = Color(hex: 0x3A93F0)  // Skalenlinie
    static let meterRed      = Color(hex: 0xFF3B30)  // roter Skalenbereich
    static let meterValue    = Color(hex: 0x2FC24A)  // Messwert-Balken (grün)
    static let txOn          = Color(hex: 0xC62828)  // TX-Knopf eingeschaltet (rot)
    static let txOnBorder    = Color(hex: 0xFF5A4F)  // Rahmen TX-Knopf eingeschaltet

    // Audiokette (aus xHost64 übernommen)
    static let pluginRow     = Color(hex: 0x2B2E33)  // Plugin-Zeilen – etwas heller als IN/OUT
    static let chainBadge    = Color(hex: 0x1E2A44)  // dunkelblaues Schildchen (Zeilennummer)
    static let meterYellow   = Color(hex: 0xFFD60A)  // gelb: Pegel wird knapp
    static let meterHot      = Color(hex: 0xFF9F0A)  // orange: über 0 dB zwischen den Plugins (unkritisch)
    static let ledOff        = Color(hex: 0x3A3E46)  // LED aus (kein Signal)
    static let inColor       = Color(hex: 0x34C759)  // Eingang: grün
    static let outColor      = Color(hex: 0xFF7A45)  // Ausgang: orange-rot
    static let search        = Color(hex: 0x34C759)  // Lupe im Suchfeld

    // MARK: RimuSDR – gemessen per Pipette (Design-Vorgabe 01.10.2026)
    // Noch nirgends benutzt – die Blöcke werden einzeln darauf umgestellt.
    static let rimuBlock       = Color(hex: 0x3A3A3A)  // Fläche eines Blocks (TX, MIC …)
    static let rimuKopf        = Color(hex: 0x1A1A1A)  // Kopfzeile eines Blocks (☰ TX)
    static let rimuSpalt       = Color(hex: 0x1E1E1E)  // Spalt zwischen den Blöcken
    static let rimuSpaltKante  = Color(hex: 0x434343)  // feine helle Kante am Spalt
    static let rimuLeiste      = Color(hex: 0x272727)  // Hintergrund Seitenleiste / leere Fläche
    static let rimuFenster     = Color(hex: 0x1E1E1E)  // Fensterhintergrund, Statusleiste
    static let rimuMenue       = Color(hex: 0x2D2D2D)  // obere Leiste
    static let rimuStatusFeld  = Color(hex: 0x1A1A1A)  // Feld in der Statusleiste
    static let rimuMeter       = Color(hex: 0x141414)  // Hintergrund der Pegelanzeigen
    static let rimuPanKopf     = Color(hex: 0x00141E)  // Kopfzeile Panadapter

    // Knöpfe
    static let knopfAusOben    = Color(hex: 0x414145)  // Knopf aus: Verlauf oben
    static let knopfAusUnten   = Color(hex: 0x38383A)  // … unten
    static let knopfLichtOben  = Color(hex: 0x58585B)  // Lichtkante oben (1 px)
    static let knopfLichtUnten = Color(hex: 0x4F4F51)  // Lichtkante unten (1 px)
    static let knopfRand       = Color(hex: 0x151515)  // äußerer Rand (1 px)
    static let knopfAnOben     = Color(hex: 0x396EB0)  // Knopf an (blau): Verlauf oben
    static let knopfAnUnten    = Color(hex: 0x2E60AB)  // … unten
    static let knopfAnRand     = Color(hex: 0x4A9FF5)  // Knopf an: heller blauer Rand
    static let knopfGesperrt   = Color(hex: 0x292929)  // gesperrt: flach

    // Zahlenfeld (z. B. TX-Filter 100 Hz)
    static let zahlFeld        = Color(hex: 0x2D2D30)
    static let zahlFeldSchatten = Color(hex: 0x2A2A2D) // oben innen, leichter Schatten
}

extension Color {
    /// Erlaubt Farben als Hex-Zahl: Color(hex: 0x1B1C1E)
    init(hex: UInt32) {
        self.init(red:   Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8)  & 0xFF) / 255,
                  blue:  Double( hex        & 0xFF) / 255)
    }
}

extension View {
    /// Macht aus einem Bereich einen Kasten mit runden Ecken (aus xHost64)
    func card(padding: CGFloat = 14, fill: Color = Theme.panel) -> some View {
        self
            .padding(padding)
            .background(RoundedRectangle(cornerRadius: 10).fill(fill))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Theme.border))
    }
}
