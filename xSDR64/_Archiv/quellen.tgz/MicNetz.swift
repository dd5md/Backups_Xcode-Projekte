import ApiPackage
import Foundation
import Observation
import os
import Synchronization

// MARK: - Empfang (UDP-Queue)

/// Mikrofon vom Flex übers Netz (DAX MIC: 24 kHz, Stereo, Float32 Big Endian).
/// Misst den Pegel und schreibt den Ton in den Eingang der Audiokette
/// (Zahnrad-Menü → „Mikrofon vom Flex als Eingang der Audiokette“).
nonisolated final class MicNetzEmpfang: NetzEingang, @unchecked Sendable {
  static let shared = MicNetzEmpfang()

  // MARK: Eingang der Audiokette

  var name: String { "Flex-Mikrofon (Netz)" }

  /// Ziel in der Audiokette und deren Takt – gesetzt von xHostKit beim Start/Stopp der Kette
  private let ziel = OSAllocatedUnfairLock<(live: LiveAudio?, rate: Double)>(initialState: (nil, 0))

  func verbinde(_ live: LiveAudio?, rate: Double) {
    ziel.withLock { $0 = (live, rate) }
  }

  // Umrechnung 24 kHz → Takt der Kette (Catmull-Rom, mit Gedächtnis über die Pakete hinweg)
  private var verlauf: [Float] = [0, 0, 0]
  private var position: Double = 1
  private var mono = [Float](repeating: 0, count: 512)
  private var ausgabe = [Float](repeating: 0, count: 4096)

  /// nur Pakete dieses Streams annehmen (0 = keiner)
  let streamId = Atomic<UInt32>(0)
  /// Spitzenwert seit dem letzten Abholen (Float-Bits, damit es atomar bleibt)
  private let spitzeBits = Atomic<UInt32>(0)
  /// empfangene Pakete (zur Kontrolle, ob überhaupt etwas ankommt)
  let pakete = Atomic<Int>(0)

  /// Rückruf für alle DAX-/Remote-Audio-Pakete: verteilt an Mac-Audio und Netz-Mikrofon
  /// (beide nehmen nur ihren eigenen Stream an)
  static var verteiler: @Sendable (UInt32, [UInt8]) -> Void {
    let mac = MacAudioEmpfang.shared
    let mic = MicNetzEmpfang.shared
    let loop = LoopbackEmpfang.shared
    return { id, payload in
      mac.paket(id, payload)
      mic.paket(id, payload)
      loop.paket(id, payload)
    }
  }

  func paket(_ id: UInt32, _ p: [UInt8]) {
    guard id != 0, id == streamId.load(ordering: .relaxed) else { return }
    pakete.add(1, ordering: .relaxed)
    inKetteSchreiben(p)
    var spitze: Float = 0
    p.withUnsafeBytes { roh in
      let werte = roh.count / 4
      for i in 0..<werte {
        let v = abs(Float(bitPattern: UInt32(bigEndian: roh.loadUnaligned(fromByteOffset: i * 4, as: UInt32.self))))
        if v > spitze { spitze = v }
      }
    }
    // nur erhöhen – der Leser setzt beim Abholen zurück
    var alt = spitzeBits.load(ordering: .relaxed)
    while Float(bitPattern: alt) < spitze {
      let (ok, jetzt) = spitzeBits.compareExchange(expected: alt, desired: spitze.bitPattern, ordering: .relaxed)
      if ok { break }
      alt = jetzt
    }
  }

  /// Linken Kanal nehmen, auf den Takt der Kette umrechnen und in die Kette schreiben
  private func inKetteSchreiben(_ p: [UInt8]) {
    let (live, rate) = ziel.withLock { ($0.live, $0.rate) }
    guard let live, rate > 0 else { return }
    let n = p.count / 8   // Stereo-Float: 8 Byte je Frame
    guard n > 0 else { return }
    // Puffer: Verlauf (3) + neue Samples
    if mono.count < n + 3 { mono = [Float](repeating: 0, count: n + 3) }
    mono[0] = verlauf[0]; mono[1] = verlauf[1]; mono[2] = verlauf[2]
    p.withUnsafeBytes { roh in
      for i in 0..<n {
        mono[3 + i] = Float(bitPattern: UInt32(bigEndian: roh.loadUnaligned(fromByteOffset: i * 8, as: UInt32.self)))
      }
    }
    let schritt = 24_000 / rate
    var pos = position
    var anzahl = 0
    let maxAus = Int(Double(n) / schritt) + 4
    if ausgabe.count < maxAus { ausgabe = [Float](repeating: 0, count: maxAus) }
    while pos < Double(n + 1) && anzahl < ausgabe.count {
      let i = Int(pos)
      let t = Float(pos - Double(i))
      let a = mono[i - 1], b = mono[i], c = mono[i + 1], d = mono[i + 2]
      // Catmull-Rom: weicher als linear, ohne Überschwinger
      ausgabe[anzahl] = b + 0.5 * t * (c - a + t * (2 * a - 5 * b + 4 * c - d + t * (3 * (b - c) + d - a)))
      anzahl += 1
      pos += schritt
    }
    position = pos - Double(n)
    verlauf[0] = mono[n]; verlauf[1] = mono[n + 1]; verlauf[2] = mono[n + 2]
    ausgabe.withUnsafeBufferPointer { live.writeMono($0.baseAddress!, frames: anzahl) }
  }

  /// Spitzenwert abholen und zurücksetzen (0…1, linear)
  func holeSpitze() -> Float {
    Float(bitPattern: spitzeBits.exchange(0, ordering: .relaxed))
  }
}

// MARK: - Modell für die Oberfläche

@MainActor
@Observable
final class MicNetz {
  static let shared = MicNetz()
  private init() {}

  private(set) var aktiv = false
  /// Pegel in dBFS (−60 … 0), ~20 mal pro Sekunde
  private(set) var pegelDb: Float = -60
  private(set) var paketeProSekunde = 0

  private var uhr: Timer?
  private var letztePakete = 0
  private var zaehler = 0
  private var radio: RadioVerbindung { RadioVerbindung.shared }

  func umschalten() { aktiv ? stoppen() : starten() }

  func starten() {
    guard !aktiv, radio.istVerbunden else { return }
    aktiv = true
    // Audiokette: Eingang = Flex-Mikrofon übers Netz (laufende Kette startet neu)
    let host = AudioWelt.shared.host
    host.netzEingang = MicNetzEmpfang.shared
    host.netzAktiv = true
    radio.sende("stream create type=dax_mic")
    // warten, bis das Radio den Stream meldet
    Task {
      for _ in 0..<40 {
        if let id = radio.api.daxMicAudio?.id {
          MicNetzEmpfang.shared.streamId.store(id, ordering: .relaxed)
          break
        }
        try? await Task.sleep(for: .milliseconds(100))
      }
    }
    uhr = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
      MainActor.assumeIsolated { MicNetz.shared.messen() }
    }
  }

  func stoppen() {
    guard aktiv else { return }
    aktiv = false
    AudioWelt.shared.host.netzAktiv = false   // Kette zurück auf das Eingabegerät
    uhr?.invalidate()
    uhr = nil
    if let id = radio.api.daxMicAudio?.id, radio.istVerbunden {
      radio.sende("stream remove 0x\(String(id, radix: 16, uppercase: true))")
    }
    MicNetzEmpfang.shared.streamId.store(0, ordering: .relaxed)
    pegelDb = -60
    paketeProSekunde = 0
  }

  private func messen() {
    let s = MicNetzEmpfang.shared.holeSpitze()
    let db = s > 0 ? 20 * log10(s) : -60
    // schnell hoch, langsam runter – wie ein Pegelmesser
    pegelDb = max(-60, max(db, pegelDb - 1.5))
    zaehler += 1
    if zaehler >= 20 {
      let p = MicNetzEmpfang.shared.pakete.load(ordering: .relaxed)
      paketeProSekunde = p - letztePakete
      letztePakete = p
      zaehler = 0
    }
  }
}
