import ApiPackage
import SwiftUI

/// Fenster „Radio-Einstellungen“ (wie „FLEX-8600M settings“ bei SmartSDR), mit Reitern.
/// Bewusst weggelassen: CW, RTTY, Digital-/CW-Filter (xSDR64 ist auf SSB-Sprache ausgelegt).
struct RadioEinstellungen: View {
  @State private var radio = RadioVerbindung.shared
  @AppStorage("radioEinstellungenReiter") private var reiter = "Information"
  private let reiterNamen = ["Information", "General", "GPS", "Transmit", "Phone", "Receive", "Filters", "ATU"]

  var body: some View {
    Group {
      if let r = radio.radio {
        VStack(spacing: 0) {
          // Reiter als Knopfleiste – alle nebeneinander (wie die Tabs der rechten Seitenleiste)
          HStack(spacing: Abstand.xs) {
            ForEach(reiterNamen, id: \.self) { name in
              Button(name) { reiter = name }
                .buttonStyle(KnopfStil(art: reiter == name ? .an : .aus))
            }
          }
          .padding(Abstand.m)
          .frame(maxWidth: .infinity)
          .background(Theme.bar)

          Group {
            switch reiter {
            case "General": AllgemeinReiter(r: r)
            case "GPS": GpsReiter()
            case "Transmit": SendenReiter()
            case "Phone": PhoneReiter()
            case "Receive": EmpfangReiter(r: r)
            case "Filters": FilterReiter(r: r)
            case "ATU": AtuReiter()
            default: InfoReiter(r: r)
            }
          }
          .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        }
      } else {
        VStack {
          Spacer()
          Text("Radio nicht verbunden").font(Schrift.normal).foregroundStyle(Theme.textDim)
          Spacer()
        }
        .frame(maxWidth: .infinity)
      }
    }
    .frame(width: 680, height: 660)
    .background(Theme.window)
  }
}

// MARK: - Bausteine

private func sende(_ befehl: String) { RadioVerbindung.shared.sende(befehl) }

/// Zeile „Titel …… Inhalt“ in einem Formular
private struct Zeile<Inhalt: View>: View {
  let titel: String
  @ViewBuilder let inhalt: Inhalt
  var body: some View {
    LabeledContent { inhalt } label: { Text(titel).foregroundStyle(Theme.textDim) }
  }
}

/// Häkchen, das beim Umschalten einen Befehl schickt (Wert kommt vom Radio zurück)
private struct Haken: View {
  let titel: String
  let wert: Bool
  let befehl: (Bool) -> String
  var body: some View {
    Toggle(titel, isOn: Binding(get: { wert }, set: { sende(befehl($0)) }))
      .toggleStyle(.checkbox)
  }
}

/// Zahl eintippen (Enter oder Verlassen übernimmt)
private struct ZahlFeld: View {
  let wert: Int
  var einheit = ""
  var bereich: ClosedRange<Int> = 0...10_000
  let befehl: (Int) -> String
  @State private var text = ""
  @FocusState private var fokus: Bool
  var body: some View {
    HStack(spacing: 4) {
      TextField("", text: $text)
        .multilineTextAlignment(.trailing)
        .textFieldStyle(.roundedBorder)
        .frame(width: 70)
        .focused($fokus)
        .onAppear { text = "\(wert)" }
        .onChange(of: wert) { _, neu in if !fokus { text = "\(neu)" } }
        .onSubmit(uebernehmen)
        .onChange(of: fokus) { _, jetzt in if !jetzt { uebernehmen() } }
      if !einheit.isEmpty { Text(einheit).foregroundStyle(Theme.textDim) }
    }
  }
  private func uebernehmen() {
    guard let n = Int(text.trimmingCharacters(in: .whitespaces)) else { text = "\(wert)"; return }
    let b = min(bereich.upperBound, max(bereich.lowerBound, n))
    text = "\(b)"
    if b != wert { sende(befehl(b)) }
  }
}

/// Text eintippen (Enter oder Verlassen übernimmt)
private struct TextFeld: View {
  let wert: String
  let befehl: (String) -> String
  @State private var text = ""
  @FocusState private var fokus: Bool
  var body: some View {
    TextField("", text: $text)
      .textFieldStyle(.roundedBorder)
      .frame(width: 200)
      .focused($fokus)
      .onAppear { text = wert }
      .onChange(of: wert) { _, neu in if !fokus { text = neu } }
      .onSubmit(uebernehmen)
      .onChange(of: fokus) { _, jetzt in if !jetzt { uebernehmen() } }
  }
  private func uebernehmen() {
    let neu = text.trimmingCharacters(in: .whitespaces)
    guard !neu.isEmpty, !neu.contains(" "), neu != wert else { text = wert; return }
    sende(befehl(neu))
  }
}

// MARK: - Reiter

private struct InfoReiter: View {
  let r: Radio
  private func oder(_ a: String, _ b: String) -> String { ohneAnf(a.isEmpty ? b : a) }
  private func ohneAnf(_ s: String) -> String { s.trimmingCharacters(in: CharacterSet(charactersIn: "\"")) }
  var body: some View {
    Form {
      Zeile(titel: "Modell") { Text(oder(r.radioModel, r.packet.model)) }
      Zeile(titel: "Seriennummer") { Text(oder(r.chassisSerial, r.packet.serial)).textSelection(.enabled) }
      Zeile(titel: "Firmware") { Text(oder(r.softwareVersion, r.packet.version)) }
      Zeile(titel: "IP-Adresse") { Text(oder(r.ipAddress, r.packet.publicIp)).textSelection(.enabled) }
      Zeile(titel: "MAC-Adresse") { Text(r.macAddress).textSelection(.enabled) }
      Zeile(titel: "Region") { Text(ohneAnf(r.region)) }
      Zeile(titel: "Optionen") { Text(ohneAnf(r.radioOptions)) }
      Zeile(titel: "Slices / Panadapter") { Text("\(r.availableSlices) / \(r.availablePanadapters) frei") }
    }
    .formStyle(.grouped)
  }
}

private struct AllgemeinReiter: View {
  let r: Radio
  var body: some View {
    Form {
      Zeile(titel: "Nickname") { TextFeld(wert: r.name.isEmpty ? r.packet.nickname : r.name) { "radio name \($0)" } }
      Zeile(titel: "Rufzeichen") { TextFeld(wert: r.callsign.isEmpty ? r.packet.callsign : r.callsign) { "radio callsign \($0)" } }
      Haken(titel: "Remote On (Einschalten über RCA-Eingang)", wert: r.remoteOnEnabled) {
        "radio set remote_on_enabled=\($0 ? 1 : 0)"
      }
      Haken(titel: "MultiFlex eingeschaltet", wert: r.multiflexEnabled) { "radio set mf_enable=\($0 ? 1 : 0)" }
      Haken(titel: "Nur Verbindungen aus privaten IP-Bereichen", wert: r.enforcePrivateIpEnabled) {
        "radio set enforce_private_ip_connections=\($0 ? 1 : 0)"
      }
    }
    .formStyle(.grouped)
  }
}

private struct GpsReiter: View {
  @State private var radio = RadioVerbindung.shared
  var body: some View {
    let g = radio.api.gps
    Form {
      if g.installed {
        Zeile(titel: "Status") { Text(g.status) }
        Zeile(titel: "Satelliten") { Text("\(g.tracked) verfolgt / \(g.visible) sichtbar") }
        Zeile(titel: "Breite") { Text(g.latitude) }
        Zeile(titel: "Länge") { Text(g.longitude) }
        Zeile(titel: "Locator") { Text(g.grid) }
        Zeile(titel: "Höhe") { Text(g.altitude) }
        Zeile(titel: "UTC") { Text(g.time) }
        Zeile(titel: "Geschwindigkeit") { Text(g.speed) }
        Zeile(titel: "Frequenzfehler") { Text(String(format: "%.1f ppb", g.frequencyError)) }
      } else {
        Text(g.status.isEmpty ? "Noch keine GPS-Daten vom Radio" : "GPS: \(g.status)").foregroundStyle(Theme.textDim)
      }
    }
    .formStyle(.grouped)
  }
}

private struct SendenReiter: View {
  @State private var radio = RadioVerbindung.shared
  var body: some View {
    let i = radio.api.interlock, t = radio.api.transmit
    Form {
      Section("Timing (Endstufe & Co.)") {
        HStack {
          Haken(titel: "ACC TX", wert: i.accTxEnabled) { "interlock acc_tx_enabled=\($0 ? 1 : 0)" }
          Spacer()
          ZahlFeld(wert: i.accTxDelay, einheit: "ms") { "interlock acc_tx_delay=\($0)" }
        }
        HStack {
          Haken(titel: "RCA TX 1", wert: i.tx1Enabled) { "interlock tx1_enabled=\($0 ? 1 : 0)" }
          Spacer()
          ZahlFeld(wert: i.tx1Delay, einheit: "ms") { "interlock tx1_delay=\($0)" }
        }
        HStack {
          Haken(titel: "RCA TX 2", wert: i.tx2Enabled) { "interlock tx2_enabled=\($0 ? 1 : 0)" }
          Spacer()
          ZahlFeld(wert: i.tx2Delay, einheit: "ms") { "interlock tx2_delay=\($0)" }
        }
        HStack {
          Haken(titel: "RCA TX 3", wert: i.tx3Enabled) { "interlock tx3_enabled=\($0 ? 1 : 0)" }
          Spacer()
          ZahlFeld(wert: i.tx3Delay, einheit: "ms") { "interlock tx3_delay=\($0)" }
        }
        Zeile(titel: "TX Delay") { ZahlFeld(wert: i.txDelay, einheit: "ms") { "interlock tx_delay=\($0)" } }
        Zeile(titel: "Timeout") {
          // Radio rechnet in ms, angezeigt in Minuten wie bei SmartSDR
          ZahlFeld(wert: i.timeout / 60_000, einheit: "min", bereich: 0...120) { "interlock timeout=\($0 * 60_000)" }
        }
      }
      Section("Sender") {
        Zeile(titel: "Max. Leistung") {
          ZahlFeld(wert: t.maxPowerLevel, einheit: "%", bereich: 0...100) { "transmit set max_power_level=\($0)" }
        }
        Haken(titel: "Full Duplex", wert: radio.radio?.fullDuplexEnabled ?? false) {
          "radio set full_duplex_enabled=\($0 ? 1 : 0)"
        }
        Haken(titel: "Hardware-ALC", wert: t.hwAlcEnabled) { "transmit set hwalc_enabled=\($0 ? 1 : 0)" }
        Haken(titel: "Sendesignal im Wasserfall zeigen", wert: t.txInWaterfallEnabled) {
          "transmit set show_tx_in_waterfall=\($0 ? 1 : 0)"
        }
        Haken(titel: "TX Inhibit (Senden sperren)", wert: t.inhibit) { "transmit set inhibit=\($0 ? 1 : 0)" }
      }
    }
    .formStyle(.grouped)
  }
}

private struct PhoneReiter: View {
  @State private var radio = RadioVerbindung.shared
  var body: some View {
    let t = radio.api.transmit
    Form {
      Haken(titel: "Mikrofon-Bias (Phantomspeisung für Elektret)", wert: t.micBiasEnabled) { "mic bias \($0 ? 1 : 0)" }
      Haken(titel: "Mikrofon-Boost (+20 dB)", wert: t.micBoostEnabled) { "mic boost \($0 ? 1 : 0)" }
      Haken(titel: "Pegelanzeige auch beim Empfang", wert: t.meterInRxEnabled) { "transmit set met_in_rx=\($0 ? 1 : 0)" }
    }
    .formStyle(.grouped)
  }
}

private struct EmpfangReiter: View {
  let r: Radio
  var body: some View {
    Form {
      Zeile(titel: "Referenz-Oszillator") {
        Picker("", selection: Binding(get: { r.setting }, set: { sende("radio oscillator \($0)") })) {
          if !["auto", "external", "gpsdo", "tcxo"].contains(r.setting) { Text(r.setting).tag(r.setting) }
          Text("Auto").tag("auto")
          Text("Extern").tag("external")
          Text("GPSDO").tag("gpsdo")
          Text("TCXO").tag("tcxo")
        }
        .labelsHidden()
        .frame(width: 140)
      }
      Zeile(titel: "Status") { Text(r.locked ? "eingerastet (\(r.state))" : r.state) }
      Haken(titel: "Binaurales Audio", wert: r.binauralRxEnabled) { "radio set binaural_rx=\($0 ? 1 : 0)" }
      Haken(titel: "TNFs global einschalten", wert: r.tnfsEnabled) { "radio set tnf_enabled=\($0 ? 1 : 0)" }
      Haken(titel: "Lokalen Ton stummschalten bei Fernbetrieb", wert: r.muteLocalAudio) {
        "radio set mute_local_audio_when_remote=\($0 ? 1 : 0)"
      }
    }
    .formStyle(.grouped)
  }
}

private struct FilterReiter: View {
  let r: Radio
  var body: some View {
    Form {
      Section("Sprache (Voice)") {
        Haken(titel: "Automatisch", wert: r.filterVoiceAutoEnabled) {
          "radio filter_sharpness voice auto_level=\($0 ? 1 : 0)"
        }
        Zeile(titel: "Schärfe") {
          HStack {
            Slider(value: Binding(get: { Double(r.filterVoiceLevel) },
                                  set: { sende("radio filter_sharpness voice level=\(Int($0))") }),
                   in: 0...3, step: 1)
              .frame(width: 180)
            Text("\(r.filterVoiceLevel)").font(Schrift.zahl).frame(width: 20)
          }
        }
        .disabled(r.filterVoiceAutoEnabled)
      }
      Text("Höhere Schärfe = steilere Filterflanken, aber mehr Verzögerung.")
        .font(Schrift.klein).foregroundStyle(Theme.textDim)
    }
    .formStyle(.grouped)
  }
}

private struct AtuReiter: View {
  @State private var frage = false
  var body: some View {
    Form {
      Button("Alle ATU-Speicher löschen …") { frage = true }
      Text("Löscht die gespeicherten Abstimmwerte des eingebauten Antennentuners.")
        .font(Schrift.klein).foregroundStyle(Theme.textDim)
    }
    .formStyle(.grouped)
    .confirmationDialog("Alle ATU-Speicher im Radio löschen?", isPresented: $frage, titleVisibility: .visible) {
      Button("Löschen", role: .destructive) { sende("atu clear") }
      Button("Abbrechen", role: .cancel) {}
    }
  }
}
