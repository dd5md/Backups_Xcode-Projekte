import ApiPackage
import SwiftUI

/// Obere Leiste (RimuSDR-Stil):
/// links Lautsprecher + Kopfhörer, Mitte aktiver Slice, rechts Audio-Weg + Verbindung
struct TopBar: View {
  enum AudioOut: String, CaseIterable, Identifiable {
    case radio = "Radio", mac = "Mac"
    var id: String { rawValue }
  }

  // Lautstärken bleiben über Neustarts erhalten
  @AppStorage("lautsprecherLautstaerke") private var speaker = 60.0  // bleibt über Neustarts erhalten
  @AppStorage("lautsprecherStumm") private var speakerMuted = false
  @AppStorage("kopfhoererLautstaerke") private var phones = 50.0
  @State private var phonesMuted = false
  private let macAudio = MacAudio.shared
  /// Audio-Weg: Radio (Lautsprecher/Kopfhörer am Flex) oder Mac (Ton über das Netz)
  private var audioOut: AudioOut { macAudio.aufMac ? .mac : .radio }
  @State private var zeigeRadios = false  // Radio-Auswahl offen?
  private let verbindung = RadioVerbindung.shared
  @State private var showSettings = false  // Zahnrad-Popup offen?
  @State private var recording = false
  @State private var globalProfil = "Default"

  var body: some View {
    HStack(spacing: 14) {
      // Lautsprecher
      volume(icon: speakerMuted ? "speaker.slash.fill" : "speaker.wave.2.fill",
             muted: $speakerMuted, value: $speaker, help: "Lautsprecher")
        // regelt die Lautstärke des Mac-Tons (bei „Audio: Mac“)
        .onChange(of: speaker, initial: true) { _, neu in macAudio.lautstaerke = Float(neu / 100) }
        .onChange(of: speakerMuted, initial: true) { _, neu in macAudio.stumm = neu }
      // Kopfhörer
      volume(icon: "headphones", muted: $phonesMuted, value: $phones, help: "Kopfhörer")

      // Zahnrad: Audio-Einstellungen
      Button { showSettings.toggle() } label: {
        Image(systemName: "gearshape")
          .font(Schrift.normal)
          .foregroundStyle(showSettings ? Theme.meterBlue : Theme.text)
          .frame(width: 24, height: 24)
          .contentShape(Rectangle())
      }
      .buttonStyle(.plain)
      .focusEffectDisabled()
      .help("Audio-Einstellungen")
      .popover(isPresented: $showSettings, arrowEdge: .bottom) {
        AudioSettingsPopup(
          useRadio: Binding(get: { audioOut == .radio },
                            set: { macAudio.aufMac = !$0 }),
          lineout: $speaker, lineoutOn: Binding(get: { !speakerMuted }, set: { speakerMuted = !$0 }),
          headset: $phones, headsetOn: Binding(get: { !phonesMuted }, set: { phonesMuted = !$0 }))
      }

      // Aufnahme – rot, solange aufgenommen wird
      TagButton(title: recording ? "● Rec" : "Rec", isOn: recording, onColor: Theme.txOn) {
        recording.toggle()
      }
      .help("Aufnahme: Quelle im Zahnrad-Menü wählen")

      Spacer(minLength: 0)

      // Aktiver Slice
      let s = verbindung.meinSlice
      let hz = s?.frequency ?? 14_200_000
      HStack(spacing: 8) {
        Text(s?.sliceLetter ?? "A")
          .font(Schrift.normalFett)
          .foregroundStyle(.white)
          .frame(width: 22, height: 20)
          .background(RoundedRectangle(cornerRadius: 3).fill(Theme.accent))
        Text(RXBlock.format(hz))
          .font(Schrift.gross.monospacedDigit())
        Text([s?.mode ?? "USB", RadioVerbindung.band(hz)].filter { !$0.isEmpty }.joined(separator: " · "))
          .foregroundStyle(Theme.textDim)
      }

      Spacer(minLength: 0)

      // Globales Profil des Radios (Bänder, Slices, Panadapter …)
      HStack(spacing: 4) {
        Text("Profil:")
          .foregroundStyle(Theme.textDim)
        RimuPicker(selection: verbindung.profilWahl("global", $globalProfil),
                   options: verbindung.profilListe("global")) { $0 }
          .frame(width: 150)
      }
      .help("Globales Profil")

      // Audio-Weg: über das Radio oder über den Mac
      HStack(spacing: 4) {
        Text("Audio:")
          .foregroundStyle(Theme.textDim)
        ForEach(AudioOut.allCases) { out in
          TagButton(title: out.rawValue, isOn: audioOut == out) { macAudio.aufMac = (out == .mac) }
        }
      }

      // Verbindung zum Radio
      // verbunden: trennt sofort; getrennt: verbindet direkt, wenn genau ein Radio da ist, sonst Auswahl
      TagButton(title: verbindung.istVerbunden ? "Trennen" : "Verbinden", isOn: false) {
        if verbindung.istVerbunden {
          Task { await verbindung.trennen() }
        } else if let radio = verbindung.letztesGefundenesRadio
                    ?? (verbindung.gefundeneRadios.count == 1 ? verbindung.gefundeneRadios.first : nil) {
          // zuletzt benutztes Radio (oder das einzige) direkt verbinden – Auswahl nur bei mehreren/keinem
          Task { await verbindung.verbinden(radio) }
        } else {
          zeigeRadios.toggle()
        }
      }
      .popover(isPresented: $zeigeRadios, arrowEdge: .bottom) {
        RadioAuswahl()
      }
    }
    .font(Schrift.normal)
    .padding(.horizontal, 14)
    .frame(height: 40)
    .background(Theme.bar)
  }

  /// Symbol (Klick = stumm) + kurzer Lautstärkeregler
  private func volume(icon: String, muted: Binding<Bool>, value: Binding<Double>, help: String) -> some View {
    HStack(spacing: 6) {
      Button { muted.wrappedValue.toggle() } label: {
        Image(systemName: icon)
          .font(Schrift.normal)
          .foregroundStyle(muted.wrappedValue ? Theme.meterRed : Theme.text)
          .frame(width: 22, height: 22)
          .contentShape(Rectangle())
      }
      .buttonStyle(.plain)
      .focusEffectDisabled()
      .help("\(help): Klick = stumm")
      Slider(value: value, in: 0...100)
        .controlSize(.small)
        .frame(width: 110)
        .disabled(muted.wrappedValue)
    }
  }
}

// MARK: - Zahnrad-Popup: Audio-Einstellungen
struct AudioSettingsPopup: View {
  enum Buffer: String, CaseIterable, Identifiable {
    case small = "Klein", medium = "Mittel", large = "Groß"
    var id: String { rawValue }
  }
  enum RecSource: String, CaseIterable, Identifiable {
    case tx = "Sendeton (nach Audiokette)"
    case rx = "Empfang"
    case both = "Beides"
    var id: String { rawValue }
  }

  @Binding var useRadio: Bool
  @Binding var lineout: Double
  @Binding var lineoutOn: Bool
  @Binding var headset: Double
  @Binding var headsetOn: Bool

  // Ausgabe und Puffer sind echt. NOCH OHNE FUNKTION (Platzhalter, siehe Offene Punkte):
  // Eingang, „Nur hören“, Aufnahme-Quelle, „TNFs global“
  private let macAudio = MacAudio.shared
  @State private var inputDevice = "MacBook Pro-Mikrofon"
  @State private var listenOnly = false
  @State private var recSource: RecSource = .tx
  @State private var tnfGlobal = false
  private let inputs = ["MacBook Pro-Mikrofon", "RME Fireface UCX II"]

  var body: some View {
    VStack(alignment: .leading, spacing: 12) {
      section("Mac-Audio") {
        row("Ausgabe:") {
          // echte Mac-Geräte; leer = Standard des Systems
          Picker("", selection: Binding(get: { macAudio.ausgabeUID }, set: { macAudio.ausgabeUID = $0 })) {
            Text("System-Standard").tag("")
            ForEach(macAudio.ausgaben) { Text($0.name).tag($0.uid) }
          }
          .labelsHidden()
        }
        row("Puffer:") {
          Picker("", selection: Binding(get: { Buffer.allCases[min(max(macAudio.puffer, 0), 2)] },
                                        set: { macAudio.puffer = Buffer.allCases.firstIndex(of: $0) ?? 1 })) {
            ForEach(Buffer.allCases) { Text($0.rawValue).tag($0) }
          }
            .pickerStyle(.segmented)
            .labelsHidden()
        }
        row("Eingang:") {
          Picker("", selection: $inputDevice) { ForEach(inputs, id: \.self) { Text($0) } }
            .labelsHidden()
            .disabled(listenOnly)
        }
        Toggle("Nur hören (kein Mac-Eingang)", isOn: $listenOnly)
          .toggleStyle(.checkbox)
      }

      section("Radio-Audio") {
        Toggle("Ausgabe über das Radio (statt Mac)", isOn: $useRadio)
          .toggleStyle(.checkbox)
        volumeRow("Lineout:", value: $lineout, isOn: $lineoutOn)
        volumeRow("Kopfhörer:", value: $headset, isOn: $headsetOn)
      }

      // Nur für den Betrieb OHNE Audio-Interface (z. B. Laptop im WLAN, Mikrofon direkt am Flex)
      section("Audio über Netzwerk (ohne Audio-Interface)") {
        let mic = MicNetz.shared
        let tx = TxNetz.shared
        Toggle("Mikrofon vom Flex als Eingang der Audiokette",
               isOn: Binding(get: { mic.aktiv }, set: { _ in mic.umschalten() }))
          .toggleStyle(.checkbox)
        if mic.aktiv {
          Text("Pegel \(Int(mic.pegelDb)) dB · \(mic.paketeProSekunde) Pakete/s")
            .font(Schrift.klein.monospacedDigit())
            .foregroundStyle(Theme.textDim)
        }
        Toggle("Audiokette sendet übers Netzwerk (statt Kabel an BAL)",
               isOn: Binding(get: { tx.aktiv }, set: { _ in tx.umschalten() }))
          .toggleStyle(.checkbox)
        if !tx.meldung.isEmpty {
          Text(tx.meldung).font(Schrift.klein).foregroundStyle(Theme.textDim)
        }
      }
      .disabled(!RadioVerbindung.shared.istVerbunden)

      section("Aufnahme (Rec)") {
        row("Quelle:") {
          Picker("", selection: $recSource) { ForEach(RecSource.allCases) { Text($0.rawValue).tag($0) } }
            .labelsHidden()
        }
      }

      Toggle("TNFs global aktivieren", isOn: $tnfGlobal)
        .toggleStyle(.checkbox)
    }
    .font(Schrift.normal)
    .padding(16)
    .frame(width: 400)
  }

  /// Abschnitt mit kleiner Überschrift und abgesetztem Hintergrund
  private func section<Content: View>(_ title: String, @ViewBuilder _ content: () -> Content) -> some View {
    VStack(alignment: .leading, spacing: 6) {
      Text(title)
        .font(Schrift.kleinFett)
        .foregroundStyle(Theme.textDim)
      VStack(alignment: .leading, spacing: 10) { content() }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.05)))
    }
  }

  /// Zeile: Bezeichnung – Bedienelement
  private func row<Content: View>(_ label: String, @ViewBuilder _ content: () -> Content) -> some View {
    HStack(spacing: 10) {
      Text(label).frame(width: 80, alignment: .leading)
      content()
    }
  }

  /// Zeile: Bezeichnung – Regler – Häkchen (ein/aus)
  private func volumeRow(_ label: String, value: Binding<Double>, isOn: Binding<Bool>) -> some View {
    HStack(spacing: 10) {
      Text(label).frame(width: 80, alignment: .leading)
      Slider(value: value, in: 0...100).controlSize(.small)
      Toggle("", isOn: isOn).toggleStyle(.checkbox).labelsHidden()
    }
  }
}
